<?php

namespace Modules\Notifications\Listeners;

use Modules\Notifications\Events\OrderStatusWasChanged;
use Modules\Notifications\Notifications\OrderCompletedNotification;
use Modules\Notifications\Notifications\OrderReadyForPickupNotification;
use Modules\Notifications\Notifications\OrderStatusWasChangedNotification;

class SendOrderStatusWasChangedNotification
{
    public function handle(OrderStatusWasChanged $event): void
    {
        $order = $event->order;
        $user = $order->user;

        match ($order->status) {
            'ready'=> $user->notify(new OrderReadyForPickupNotification($order)),
            'completed'       => $user->notify(new OrderCompletedNotification($order)),
            default           => null,
        };
    }
}
