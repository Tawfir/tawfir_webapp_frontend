<?php

namespace Modules\Notifications\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class NotificationController extends Controller
{
    public function index(Request $request)
    {
        return $this->success(
            ['notifications' => $request->user()->notifications()->paginate(10),
                'unread_count' => $request->user()->unreadNotifications()->count()
            ],
            'Notifications retrieved successfully'
        );
    }

    public function markAsRead(Request $request, $id)
    {
        $request->user()
            ->notifications()
            ->where('id', $id)
            ->update(['read_at' => now()]);

        return response()->noContent();
    }

    public function unreadCount(Request $request)
    {
        return response()->json([
            'count' => $request->user()->unreadNotifications()->count(),
        ]);
    }
}
