<?php

namespace Modules\Notifications\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use NotificationChannels\OneSignal\OneSignalChannel;
use NotificationChannels\OneSignal\OneSignalMessage;
use Illuminate\Notifications\Messages\DatabaseMessage; // if you want a nicer DB payload
use Modules\User\Entities\Order;

class OrderStatusWasChangedNotification extends Notification
{
    use Queueable;

    public function __construct(protected Order $order) {}

    public function via($notifiable): array
    {
        return [
            'database',                // in-app bell
            // OneSignalChannel::class,   // push (temporarily disabled)
        ];
    }

    public function toDatabase($notifiable): array
    {
        return [
            'order_id'   => $this->order->id,
            'title'     => $this->order->status,
            'message'    => "Your order #{$this->order->id} is now {$this->order->status}.",
        ];
    }

    public function toOneSignal($notifiable): OneSignalMessage
    {
        return OneSignalMessage::create()
            ->setSubject("Order #{$this->order->id} status")   // ← use setSubject()
            ->setBody("Your order is now {$this->order->status}.")
            ->setData('type', 'order_status')
            ->setData('order_id', $this->order->id)
            ->setData('status', $this->order->status)
            ->setData('restaurant_name', $this->order->restaurant->name) 
->setData('restaurant_address', $this->order->restaurant->address)
            ->setData('refresh_notifications', true)
        // optionally set a URL, icon, data, etc.
            // ->setUrl(route('orders.show', $this->order->id))
            ;
    }
}
