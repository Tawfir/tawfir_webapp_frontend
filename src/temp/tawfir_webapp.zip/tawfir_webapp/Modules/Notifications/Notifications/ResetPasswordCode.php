<?php

namespace Modules\Notifications\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use NotificationChannels\OneSignal\OneSignalChannel;
use NotificationChannels\OneSignal\OneSignalMessage;

class ResetPasswordCode extends Notification
{
    use Queueable;

    public function __construct(protected int $code) {}

    public function via($notifiable)
    {
        return ['mail'];
    }
    public function toMail($notifiable)
    {
        $expire = config('auth.passwords.users.expire');
        return (new MailMessage)
            ->subject('Your Password Reset Code')
            ->line("Your password reset code is **{$this->code}**.")
            ->line("This code expires in {$expire} minutes.")
            ->line('If you did not request this, you can safely ignore.');
    }
}
