<?php

namespace Modules\Notifications\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use NotificationChannels\OneSignal\OneSignalChannel;
use NotificationChannels\OneSignal\OneSignalMessage;
use Illuminate\Notifications\Messages\DatabaseMessage; // if you want a nicer DB payload
use Modules\User\Entities\Order;

class OrderReadyForPickupNotification extends Notification
{
    use Queueable;

    public function __construct(protected Order $order) {}

    public function via($notifiable): array
    {
        return ['database']; // OneSignalChannel::class temporarily disabled
    }

    public function toDatabase($notifiable): array
    {
        return [
            'order_id' => $this->order->id,
            'title'   => "Order #{$this->order->id} is ready for pickup.",
            'message'  => "Head towards the restaurant to pick your food. Address: {$this->order->restaurant->address}",
        ];
    }

    public function toOneSignal($notifiable): OneSignalMessage
    {
        return OneSignalMessage::create()
            ->setSubject("Order #{$this->order->id} is ready for pickup!")
            ->setBody("Head towards the restaurant. Address: {$this->order->restaurant->address}")
            ->setData('type', 'order_status')
            ->setData('order_id', $this->order->id)
            ->setData('status', $this->order->status)
            ->setData('restaurant_name', $this->order->restaurant->name) 
->setData('restaurant_address', $this->order->restaurant->address)
            ->setData('refresh_notifications', true)
            ;
    }
}
