<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\Notifications\Http\Controllers\NotificationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->name('user.')->prefix('user')->group(function () {

    Route::name('notifications.')->prefix('notifications')->group(function () {
        Route::get('/', [NotificationController::class,'index']);
        Route::patch('/{id}/read', [NotificationController::class,'markAsRead']);
        Route::get('/unread-count', [NotificationController::class,'unreadCount']);
    });
});