<?php

namespace Modules\Notifications\Providers;

use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    protected $listen = [
        \Modules\Notifications\Events\OrderStatusWasChanged::class => [
            \Modules\Notifications\Listeners\SendOrderStatusWasChangedNotification::class,
        ],

    ];
}
