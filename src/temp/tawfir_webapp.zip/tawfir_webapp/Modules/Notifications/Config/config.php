<?php

return [
    'name' => 'Notifications'
];
