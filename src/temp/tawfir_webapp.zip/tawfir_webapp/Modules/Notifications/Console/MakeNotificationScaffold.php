<?php

namespace Modules\Notifications\Console;

use Illuminate\Console\Command;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Str;
use Nwidart\Modules\Facades\Module;

class MakeNotificationScaffold extends Command
{
    /**
     * The name and signature of the console command.
     * Added module argument to target specific module
     *
     * @var string
     */
    protected $signature = 'module:make-notify {module} {name} {description?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Scaffold Event, Listener, Notification inside a module and register them.';

    /**
     * Execute the console command.
     *
     * @param Filesystem $files
     * @return int
     */
    public function handle(Filesystem $files)
    {
        // Resolve module
        $moduleName = Str::studly($this->argument('module'));
        $module = Module::find($moduleName);

        if (!$module) {
            $this->error("Module [{$moduleName}] not found.");
            return 1;
        }

        $modulePath = $module->getPath();
        $baseNs = $module->getStudlyName();

        // Names
        $eventName = Str::studly($this->argument('name'));
        $description = $this->argument('description') ?: $eventName;
        $listenerName = "Send{$eventName}Notification";
        $notificationName = "{$eventName}Notification";

        // 1. Create Event
        $this->callSilent('module:make-event', [
            'module' => $moduleName,
            'name' => $eventName,
        ]);

        // 2. Create Listener
        $this->callSilent('module:make-listener', [
            'module' => $moduleName,
            'name' => $listenerName,
            '--event' => $eventName,
            '--queued' => true,
        ]);

        // 3. Create Notification
        $this->callSilent('module:make-notification', [
            'module' => $moduleName,
            'name' => $notificationName,
        ]);

        // 4. Patch the Notification stub
        $notiPath = "{$modulePath}/Notifications/{$notificationName}.php";
        $stub = $files->get($notiPath);

        // Build via() method
        $via = <<<PHP
    public function via(\$notifiable)
    {
        \$channels = [];

        if (\Settings::get('notifications.mail.{$eventName}', true)) {
            \$channels[] = 'mail';
        }
        if (\Settings::get('notifications.app.{$eventName}', true)) {
            \$channels[] = 'database';
        }

        return \$channels;
    }

PHP;

        // Correctly insert description into toArray() with parameter
        $stub = preg_replace(
            '/public function toArray\([^)]*\)\s*\{/',
            "public function toArray(\$notifiable)\n    {\n        return [\n            'description' => '{$description}',",
            $stub,
            1
        );

        // Replace or append via()
        if (strpos($stub, 'public function via(') !== false) {
            $stub = preg_replace(
                '/public function via\([^}]*}/',
                trim($via),
                $stub,
                1
            );
        } else {
            $stub = str_replace(
                "class {$notificationName}",
                "class {$notificationName}\n{\n{$via}",
                $stub
            );
        }

        $files->put($notiPath, $stub);

        // 5. Register in module's EventServiceProvider
        // 5. Register in module's EventServiceProvider
        $provPath = "{$modulePath}/Providers/EventServiceProvider.php";
        $prov     = $files->get($provPath);
        $listen   = 'protected $listen = [';
        $entry    = "\n        \\Modules\\{$baseNs}\\Events\\{$eventName}::class => [\n            \\Modules\\{$baseNs}\\Listeners\\{$listenerName}::class,\n        ],";

        $prov = str_replace($listen, $listen . $entry, $prov);
        $files->put($provPath, $prov);

        $this->info("Scaffold for {$eventName} created successfully in module [{$moduleName}].");
        return 0;
    }
}