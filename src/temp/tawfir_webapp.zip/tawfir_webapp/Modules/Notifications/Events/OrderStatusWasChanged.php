<?php

namespace Modules\Notifications\Events;

use Illuminate\Queue\SerializesModels;
use Modules\User\Entities\Order;

class OrderStatusWasChanged
{
    use SerializesModels;

    public Order $order;

    public function __construct(Order $order)
    {
        $this->order = $order;
    }
}
