<?php

namespace Modules\Restaurant\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Modules\Restaurant\Enums\RestaurantStatus;

class EnsureRestaurantIsApproved
{
    public function handle(Request $request, Closure $next)
    {
        $restaurant = $request->user()->restaurant;
        if (! $restaurant || $restaurant->status !== RestaurantStatus::APPROVED) {
            return response()->json([
                'status'  => false,
                'data'    => null,
                'message' => 'Your restaurant is not approved yet.',
            ], 403);
        }
        return $next($request);
    }
}
