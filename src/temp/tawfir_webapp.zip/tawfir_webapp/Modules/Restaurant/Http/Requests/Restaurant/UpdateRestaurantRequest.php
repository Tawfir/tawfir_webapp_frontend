<?php

namespace Modules\Restaurant\Http\Requests\Restaurant;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRestaurantRequest extends FormRequest
{
    public function authorize(): bool
    {
        // only the owner may edit
        return $this->user() && $this->user()->restaurant;
    }

    public function rules(): array
    {
        return [
            'restaurant_name'    => 'nullable|string|max:255',
            'address'            => 'nullable|string',
            'lat'                => 'nullable|numeric|between:-90,90',
            'lng'                => 'nullable|numeric|between:-180,180',
            'place_pics'         => 'nullable|array',
            'place_pics.*'       => 'image|max:5120',
            'profile_pic'        => 'nullable|image|max:5120',
            'cover_image'        => 'nullable|image|max:5120',
            'working_hours'      => 'nullable|array',
            'public_phone'       => 'nullable|string',
            'private_phone'      => 'nullable|string',
            'food_category_ids'  => 'nullable|array',
            'food_category_ids.*'=> 'exists:food_categories,id',
        ];
    }

    public function messages(): array
    {
        return [
            'restaurant_name.string'       => __('Restaurant name must be a string.'),
            'restaurant_name.max'          => __('Restaurant name may not exceed 255 characters.'),

            'address.string'               => __('Address must be a string.'),

            'lat.numeric'                  => __('Latitude must be a number.'),
            'lat.between'                  => __('Latitude must be between -90 and 90.'),

            'lng.numeric'                  => __('Longitude must be a number.'),
            'lng.between'                  => __('Longitude must be between -180 and 180.'),

            'place_pics.array'             => __('Place pictures must be an array.'),
            'place_pics.*.image'           => __('Each place picture must be an image.'),
            'place_pics.*.max'             => __('Each place picture may not exceed 5 MB.'),

            'profile_pic.image'            => __('Profile picture must be an image.'),
            'profile_pic.max'              => __('Profile picture may not exceed 5 MB.'),

            'cover_image.image'            => __('Cover image must be an image.'),
            'cover_image.max'              => __('Cover image may not exceed 5 MB.'),

            'working_hours.array'          => __('Working hours must be an array.'),

            'public_phone.string'          => __('Public phone must be a string.'),
            'private_phone.string'         => __('Private phone must be a string.'),

            'food_category_ids.array'      => __('Food category IDs must be an array.'),
            'food_category_ids.*.exists'   => __('Selected food category is invalid.'),
        ];
    }

}
