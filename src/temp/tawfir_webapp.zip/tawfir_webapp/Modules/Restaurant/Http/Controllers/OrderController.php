<?php

namespace Modules\Restaurant\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
use Modules\User\Entities\Order;
use Illuminate\Validation\Rules\Enum as EnumRule;
use Modules\User\Enums\OrderStatus;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $restaurant = $request->user()->restaurant;

        $orders = Order::with(['items.dish', 'user'])
            ->where('restaurant_id', $restaurant->id)
            ->orderBy('status')
            ->latest()
            ->get();

        return $this->success([
            'orders' => $orders,
        ], 'Orders retrieved successfully');
    }

    public function show($id, Request $request)
    {
        $restaurant = $request->user()->restaurant;

        $order = Order::with(['items.dish', 'user'])
            ->where('restaurant_id', $restaurant->id)
            ->findOrFail($id);

        return $this->success([
            'order' => $order,
        ], 'Order retrieved successfully');
    }

    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status' => ['required', new EnumRule(OrderStatus::class)],
        ]);

        $restaurant = $request->user()->restaurant;

        $order = Order::where('restaurant_id', $restaurant->id)
            ->findOrFail($id);

        $order->status = OrderStatus::from($request->status);
        $order->save();

        // Send notification via OneSignal (optional based on your user_token storage)
        $this->sendOrderStatusNotification($order);

        return $this->success([
            'order'   => $order->load('items.dish'),
        ], 'Order status updated successfully');
    }

    protected function sendOrderStatusNotification(Order $order)
    {
        $user = $order->user;

        // Assume `user.notification_token` holds OneSignal player ID
        if (! $user->notification_token) return;

        Http::withHeaders([
            'Authorization' => 'Basic ' . config('services.onesignal.api_key'),
            'Content-Type'  => 'application/json',
        ])->post('https://onesignal.com/api/v1/notifications', [
            'app_id' => config('services.onesignal.app_id'),
            'include_player_ids' => [$user->notification_token],
            'headings' => ['en' => 'Order Status Updated'],
            'contents' => ['en' => "Your order #{$order->id} is now {$order->status}."],
        ]);
    }
}
