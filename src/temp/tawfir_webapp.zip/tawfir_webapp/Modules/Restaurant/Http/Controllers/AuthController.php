<?php

namespace Modules\Restaurant\Http\Controllers;

use App\Enums\UserType;
use App\Models\User;
use App\Services\ImageUploadService;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Modules\Restaurant\Entities\Restaurant;
use Modules\Restaurant\Enums\RestaurantStatus;

class AuthController extends Controller
{

}
