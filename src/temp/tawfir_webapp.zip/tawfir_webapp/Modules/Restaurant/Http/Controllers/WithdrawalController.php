<?php

namespace Modules\Restaurant\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Payment\Entities\WithdrawalRequest;
use Modules\Payment\Services\WalletService;

class WithdrawalController extends Controller
{
    /**
     * Store a new withdrawal request for the *full* wallet balance.
     */
    public function store(Request $request)
    {
        $restaurant = $request->user()->restaurant;
        $balance    = WalletService::balance($restaurant);

        // No need to accept or validate an 'amount'—we always withdraw the full balance
        if ($balance <= 0) {
            return response()->json([
                'status'  => false,
                'data'    => null,
                'message' => 'No funds available to withdraw.',
            ], 422);
        }

        $wr = WithdrawalRequest::create([
            'restaurant_id' => $restaurant->id,
            'amount'        => $balance,                  // top-up the full balance
            'method'        => $restaurant->payout_method,
            'status'        => 'pending',
        ]);

        return response()->json([
            'status'  => true,
            'data'    => $wr,
            'message' => 'Full balance withdrawal request submitted.',
        ], 201);
    }
}
