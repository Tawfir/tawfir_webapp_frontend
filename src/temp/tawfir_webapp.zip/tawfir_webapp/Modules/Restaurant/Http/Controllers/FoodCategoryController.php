<?php

namespace Modules\Restaurant\Http\Controllers;

use App\Services\ImageUploadService;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Validation\Rule;
use Modules\Restaurant\Entities\FoodCategory;

class FoodCategoryController extends Controller
{
    protected ImageUploadService $uploader;

    public function __construct(ImageUploadService $uploader)
    {
        $this->uploader = $uploader;
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories = FoodCategory::all();

        return response()->json([
            'status' => true,
            'data' => $categories,
            'message' => 'Categories retrieved successfully'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:food_categories,slug',
            'cover' => 'nullable|image',
            'image' => 'nullable|image',
        ]);

        if ($request->hasFile('cover')) {
            $data['cover'] = $this->uploader->upload($request->file('cover'), 'food-categories/covers');
        }

        if ($request->hasFile('image')) {
            $data['image'] = $this->uploader->upload($request->file('image'), 'food-categories/images');
        }

        $category = FoodCategory::create($data);

        return response()->json([
            'status' => true,
            'data' => $category,
            'message' => 'Category created successfully'
        ], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $category = FoodCategory::findOrFail($id);

        return response()->json([
            'status' => true,
            'data' => $category,
            'message' => 'Category retrieved successfully'
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $category = FoodCategory::findOrFail($id);

        $data = $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'slug' => [
                'sometimes', 'required', 'string', 'max:255',
                Rule::unique('food_categories', 'slug')->ignore($category->id)
            ],
            'cover' => 'nullable|image',
            'image' => 'nullable|image',
        ]);

        if ($request->hasFile('cover')) {
            // Optionally delete old cover via service
            $data['cover'] = $this->uploader->upload($request->file('cover'), 'food-categories/covers');
        }

        if ($request->hasFile('image')) {
            $data['image'] = $this->uploader->upload($request->file('image'), 'food-categories/images');
        }

        $category->update($data);

        return response()->json([
            'status' => true,
            'data' => $category,
            'message' => 'Category updated successfully'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $category = FoodCategory::findOrFail($id);
        $category->delete();

        return response()->json([
            'status' => true,
            'data' => null,
            'message' => 'Category deleted successfully'
        ]);
    }
}
