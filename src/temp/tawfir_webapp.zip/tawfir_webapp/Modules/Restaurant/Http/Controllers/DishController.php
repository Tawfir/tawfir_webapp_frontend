<?php

namespace Modules\Restaurant\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\ImageUploadService;
use Modules\Restaurant\Entities\Dish;

class DishController extends Controller
{
    /**
     * List all dishes for the authenticated restaurant, with all categories.
     */
    public function index(Request $request)
    {
        $dishes = $request->user()
            ->restaurant
            ->dishes()
            ->with('categories')
            ->latest()
            ->get();

        return $this->success([
            'dishes' => $dishes,
        ], 'Dishes retrieved successfully');
    }

    /**
     * Create a new dish and attach multiple categories.
     */
    public function store(Request $request, ImageUploadService $uploader)
    {
        $data = $request->validate([
            'name'                 => 'required|string|max:255',
            'image'                => 'nullable|image|max:5120',
            'price'                => 'required|numeric|min:0',
            'discounted_price'     => 'nullable|numeric|min:0',
            'co2_saved'            => 'nullable|integer|min:0',
            'description'       => 'nullable|string|max:1000',
            'pickup_time'          => 'nullable|date_format:H:i',
            'availability_method'  => 'required|in:pickup',
            'quantity'             => 'required|integer|min:1',
            'food_category_ids'    => 'required|array|min:1',
            'food_category_ids.*'  => 'exists:food_categories,id',
        ]);

        if ($request->hasFile('image')) {
            $upload = $uploader->upload($request->file('image'), 'dish');
            $data['image'] = $upload['url'];
        }

        $dish = $request->user()
            ->restaurant
            ->dishes()
            ->create($data);

        // attach the selected categories
        $dish->categories()->sync($data['food_category_ids']);

        return $this->success([
            'dish' => $dish,
        ], 'Dish created successfully');
    }

    /**
     * Update an existing dish (and optionally re‐sync categories).
     */
    public function update(Request $request, $id, ImageUploadService $uploader)
    {
        $restaurant = $request->user()->restaurant;
        $dish = $restaurant->dishes()->findOrFail($id);
        $data = $request->validate([
            'name'                 => 'nullable|string|max:255',
            'image'                => 'nullable|image|max:5120',
            'price'                => 'nullable|numeric|min:0',
            'discounted_price'     => 'nullable|numeric|min:0',
            'co2_saved'            => 'nullable|integer|min:0',
            'pickup_time'          => 'nullable|date_format:H:i',
            'description'       => 'nullable|string|max:1000',
            'availability_method'  => 'nullable|in:pickup',
            'quantity'             => 'nullable|integer|min:1',
            'food_category_ids'    => 'nullable|array|min:1',
            'food_category_ids.*'  => 'exists:food_categories,id',
        ]);


        if ($request->hasFile('image')) {
            $upload = $uploader->upload($request->file('image'), 'dish');
            $data['image'] = $upload['url'];
        }

        // update only the provided fields
        $dish->update(array_filter($data));

        // if categories were sent, re-sync them
        if (! empty($data['food_category_ids'])) {
            $dish->categories()->sync($data['food_category_ids']);
        }

        return $this->success([
            'dish' => $dish,
        ], 'Dish updated successfully');
    }

    /**
     * Delete a dish.
     */
    public function destroy(Request $request, $id)
    {
        $dish = $request->user()
            ->restaurant
            ->dishes()
            ->findOrFail($id);

        $dish->delete();

        return $this->success([], 'Dish deleted successfully');
    }
}
