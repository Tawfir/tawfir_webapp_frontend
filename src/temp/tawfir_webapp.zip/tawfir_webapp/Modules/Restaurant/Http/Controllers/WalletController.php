<?php

namespace Modules\Restaurant\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Payment\Entities\WalletTransaction;
use Modules\Payment\Services\WalletService;

class WalletController extends Controller
{
    /**
     * Return the restaurant's current wallet balance.
     */
    public function balance(Request $request)
    {
        $restaurant = $request->user()->restaurant;
        $balance    = WalletService::balance($restaurant);

        return response()->json([
            'status' => true,
            'data'   => [
                'balance' => number_format($balance, 2),
            ],
            'message' => '',
        ]);
    }

    /**
     * Return a list of wallet transactions for the restaurant.
     */
    public function transactions(Request $request)
    {
        $restaurant = $request->user()->restaurant;

        $txns = $restaurant
            ->walletTransactions()                       // ← use the morphMany relation
            ->orderBy('created_at', 'desc')
            ->get([
                'id',
                'type',
                'amount',
                'description',
                'order_id',        // this is the order foreign key
                'created_at',
            ]);

        return response()->json([
            'status' => true,
            'data'   => $txns,
            'message'=> '',
        ]);
    }
}
