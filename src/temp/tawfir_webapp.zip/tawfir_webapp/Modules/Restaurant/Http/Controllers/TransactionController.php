<?php

namespace Modules\Restaurant\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Modules\Payment\Entities\Transaction;

class TransactionController extends Controller
{
    /**
     * Mark a pending cash transaction as paid.
     */
    public function markPaid(Request $request, $id)
    {
        $txn = Transaction::where('id',$id)
            ->where('method','cash')
            ->where('status','pending')
            ->whereHas('order', fn($q) =>
            $q->where('restaurant_id', $request->user()->restaurant->id)
            )
            ->firstOrFail();

        $txn->update(['status' => 'success']);

        // Optionally update the order status too
        $txn->order->update(['status' => 'completed']);

        return $this->success($txn, __('Transaction marked as paid'));
    }
}
