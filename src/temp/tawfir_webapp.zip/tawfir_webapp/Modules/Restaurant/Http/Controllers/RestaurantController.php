<?php

namespace Modules\Restaurant\Http\Controllers;

use App\Enums\UserType;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\ImageUploadService;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Modules\Restaurant\Entities\Restaurant;
use Modules\Restaurant\Enums\RestaurantStatus;
use Modules\Restaurant\Http\Requests\Restaurant\StoreRestaurantRequest;
use Modules\Restaurant\Http\Requests\Restaurant\UpdateRestaurantRequest;

class RestaurantController extends Controller
{
    public function store(StoreRestaurantRequest $request, ImageUploadService $uploader)
    {
        $user = $request->user();

        $user->update(['type' => UserType::RESTAURANT->value]);
        $user->addRole('restaurant');

        // upload pics...
        $placePics = [];
        foreach ($request->file('place_pics', []) as $pic) {
            $placePics[] = $uploader->upload($pic, 'place')['url'];
        }
        $profilePic = $request->file('profile_pic')
            ? $uploader->upload($request->file('profile_pic'),'profile')['url']
            : null;
        $coverImage = $request->file('cover_image')
            ? $uploader->upload($request->file('cover_image'),'cover')['url']
            : null;

        // create the restaurant record
        $restaurant = $user->restaurant()->create([
            'name'           => $request->restaurant_name,
            'address'        => $request->address,
            'lat'            => $request->lat,
            'lng'            => $request->lng,
            'place_pics'     => $placePics,
            'profile_pic'    => $profilePic,
            'cover_image'    => $coverImage,
            'working_hours'  => $request->working_hours ?? json_encode([]),
            'public_phone'   => $request->public_phone,
            'private_phone'  => $request->private_phone,
            'status'         => RestaurantStatus::PENDING,
        ]);

        //$restaurant->categories()->sync($request->food_category_ids);

        return $this->success(
            ['restaurant' => $restaurant],
            __('Registration successful. Your restaurant is under review.')
        );
    }

    public function show(Request $request,$id)
    {
        if ($id){
            $restaurant = Restaurant::with('categories','dishes','dishes.categories')->find($id);
            if (! $restaurant) {
                return $this->error('Restaurant not found', 404);
            }
            return $this->success($restaurant);
        }
        $restaurant = $request->user()->restaurant()->with('categories','dishes','dishes.categories')->first();
        if (! $restaurant) {
            return $this->error('You have not created a restaurant yet', 404);
        }
        return $this->success($restaurant);
    }

    public function update(UpdateRestaurantRequest $request, ImageUploadService $uploader)
    {
        $restaurant = $request->user()->restaurant;
        if (! $restaurant) {
            return $this->error('No restaurant to update', 404);
        }

        $data = $request->validated();

        // 1️⃣ Replace place pictures if new ones are provided
        if ($request->hasFile('place_pics')) {
            $uploadedPics = [];
            foreach ($request->file('place_pics') as $pic) {
                $uploadedPics[] = $uploader->upload($pic, 'place')['url'];
            }
            $restaurant->place_pics = $uploadedPics;
        }

        // 2️⃣ Replace profile picture
        if ($request->hasFile('profile_pic')) {
            $restaurant->profile_pic = $uploader->upload(
                $request->file('profile_pic'),
                'profile'
            )['url'];
        }

        // 3️⃣ Replace cover image
        if ($request->hasFile('cover_image')) {
            $restaurant->cover_image = $uploader->upload(
                $request->file('cover_image'),
                'cover'
            )['url'];
        }

        // 4️⃣ Update the rest of the fields
        $restaurant->update([
            'name'           => $data['restaurant_name']   ?? $restaurant->name,
            'address'        => $data['address']           ?? $restaurant->address,
            'lat'            => $data['lat']               ?? $restaurant->lat,
            'lng'            => $data['lng']               ?? $restaurant->lng,
            'working_hours'  => $data['working_hours']     ?? $restaurant->working_hours,
            'public_phone'   => $data['public_phone']      ?? $restaurant->public_phone,
            'private_phone'  => $data['private_phone']     ?? $restaurant->private_phone,
        ]);

        // 5️⃣ Sync categories if the client provided any
        if (isset($data['food_category_ids'])) {
            $restaurant->categories()->sync($data['food_category_ids']);
        }

        // 6️⃣ Return the fresh restaurant with its categories
        return $this->success(
            $restaurant->fresh('categories'),
            'Restaurant updated successfully'
        );
    }
}
