<?php

return [
    'name' => 'Restaurant'
];
