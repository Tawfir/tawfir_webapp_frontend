<?php

namespace Modules\Restaurant\Enums;

enum DishAvailabilityMethod: string
{
    case PICKUP = 'pickup';
    // future: case DELIVERY = 'delivery';

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($case) => [$case->value => ucfirst($case->name)])
            ->toArray();
    }
}
