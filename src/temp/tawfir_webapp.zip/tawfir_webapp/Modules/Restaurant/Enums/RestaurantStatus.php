<?php

namespace Modules\Restaurant\Enums;
enum RestaurantStatus: string
{
    case PENDING = 'pending';
    case APPROVED = 'approved';
    case REJECTED = 'rejected';

    public static function options(): array
    {
        return collect(self::cases())
            ->mapWithKeys(fn($case) => [$case->value => ucfirst($case->name)])
            ->toArray();
    }

}
