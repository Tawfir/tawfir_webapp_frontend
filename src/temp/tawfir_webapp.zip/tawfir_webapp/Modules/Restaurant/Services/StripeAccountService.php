<?php

namespace Modules\Restaurant\Services;

use Stripe\Account;
use Stripe\AccountLink;
use Stripe\Stripe;
use Modules\Restaurant\Entities\Restaurant;

class StripeAccountService
{
    public function __construct()
    {
        Stripe::setApiKey(env('STRIPE_SECRET'));
    }

    /** Create an Express Connected Account for this restaurant */
    public function createConnectAccount(Restaurant $r): string
    {
        $acct = Account::create([
            'type'         => 'express',
            'email'        => $r->user->email,
            'capabilities' => [
                'card_payments' => ['requested'=>true],
                'transfers'     => ['requested'=>true],
            ],
        ]);
        $r->update(['stripe_account_id'=>$acct->id,'payout_method'=>'stripe']);
        return $acct->id;
    }

    /** Generate (or regenerate) an onboarding link */
    public function createOnboardingLink(Restaurant $r): string
    {
        $link = AccountLink::create([
            'account'     => $r->stripe_account_id,
            'refresh_url' => route('restaurant.stripe.refresh'),
            'return_url'  => route('restaurant.stripe.success'),
            'type'        => 'account_onboarding',
        ]);
        return $link->url;
    }
    /**
     * Generate a Stripe Express login link for a connected account.
     */
    public function createLoginLink(Restaurant $restaurant): string
    {
        $accountId = $restaurant->stripe_account_id;

        $link = Account::createLoginLink($accountId);

        return $link->url;
    }
}