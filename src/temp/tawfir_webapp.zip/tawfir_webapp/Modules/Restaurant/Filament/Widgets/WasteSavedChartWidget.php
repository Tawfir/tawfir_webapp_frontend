<?php

namespace Modules\Restaurant\Filament\Widgets;

use Filament\Widgets\ChartWidget;
use Modules\Restaurant\Entities\Dish;
use Modules\User\Entities\OrderItem;
use Modules\User\Enums\OrderStatus;

class WasteSavedChartWidget extends ChartWidget
{
    protected static ?string $pollingInterval = null;
    
    public function getHeading(): ?string
    {
        return match($this->filter) {
            'revenue' => 'Revenue Earned Over Time ($)',
            'orders' => 'Number of Completed Orders Over Time',
            default => 'Total CO₂ Saved (KG)',
        };
    }

    protected static ?int $sort = 2;

    protected int | string | array $columnSpan = 'full';

    public ?string $filter = 'co2'; // Default to CO2

    protected static ?string $maxHeight = '400px';


    protected function getData(): array
    {
        $restaurant = auth()->user()->restaurant;
        
        // Get completed orders over time (last 30 days)
        $days = 30;
        $labels = [];
        $co2Data = [];
        $revenueData = [];
        $ordersData = [];
        
        for ($i = $days - 1; $i >= 0; $i--) {
            $date = now()->subDays($i);
            $labels[] = $date->format('M d');
            
            // Get orders from this restaurant on this date
            $orders = \Modules\User\Entities\Order::query()
                ->where('restaurant_id', $restaurant->id)
                ->where('status', OrderStatus::COMPLETED->value)
                ->whereDate('created_at', $date->format('Y-m-d'))
                ->get();
            
            // Calculate totals for this day
            $co2Total = 0;
            $revenueTotal = 0;
            $orderCount = $orders->count();
            
            if ($orders->isNotEmpty()) {
                // Calculate revenue from total_price
                $revenueTotal = $orders->sum('total_price');
                
                // Calculate CO2 from order items
                $orderIds = $orders->pluck('id');
                $orderItems = OrderItem::whereIn('order_id', $orderIds)
                    ->with('dish')
                    ->get();
                
                foreach ($orderItems as $item) {
                    $co2Saved = $item->dish->co2_saved ?? 0;
                    $co2Total += $co2Saved * $item->quantity;
                }
            }
            
            $co2Data[] = round($co2Total, 2);
            $revenueData[] = round($revenueTotal, 2);
            $ordersData[] = $orderCount;
        }
        
        // Determine which dataset to show based on the selected filter
        $dataset = match($this->filter) {
            'revenue' => $revenueData,
            'orders' => $ordersData,
            default => $co2Data,
        };
        
        $label = match($this->filter) {
            'revenue' => 'Revenue Earned ($)',
            'orders' => 'Number of Completed Orders',
            default => 'CO₂ Saved (KG)',
        };
        
        return [
            'datasets' => [
                [
                    'label' => $label,
                    'data' => $dataset,
                    'backgroundColor' => 'rgba(34, 197, 94, 0.1)',
                    'borderColor' => 'rgb(34, 197, 94)',
                    'fill' => true,
                ],
            ],
            'labels' => $labels,
        ];
    }

    protected function getType(): string
    {
        return 'line';
    }

    protected function getFilters(): ?array
    {
        return [
            'co2' => 'CO₂',
            'revenue' => 'Revenue',
            'orders' => 'Orders',
        ];
    }

    protected function getOptions(): array
    {
        // Determine the current label and unit for proper formatting
        $unit = match($this->filter ?? 'co2') {
            'revenue' => '$',
            'orders' => 'orders',
            default => 'KG',
        };
        
        $label = match($this->filter ?? 'co2') {
            'revenue' => 'Revenue Earned ($)',
            'orders' => 'Number of Completed Orders',
            default => 'CO₂ Saved (KG)',
        };
        
        return [
            'animation' => [
                'duration' => 1000,
                'easing' => 'easeInOutCubic',
                'properties' => ['x', 'y'],
            ],
            'animations' => [
                'x' => [
                    'duration' => 1000,
                    'easing' => 'easeInOutCubic',
                ],
                'y' => [
                    'duration' => 1000,
                    'easing' => 'easeInOutCubic',
                ],
            ],
            'plugins' => [
                'tooltip' => [
                    'enabled' => true,
                    'backgroundColor' => 'rgba(17, 24, 39, 0.95)',
                    'titleColor' => '#F9FAFB',
                    'titleFont' => [
                        'size' => 13,
                        'weight' => '600',
                    ],
                    'bodyColor' => '#D1D5DB',
                    'bodyFont' => [
                        'size' => 13,
                    ],
                    'borderColor' => 'rgba(34, 197, 94, 0.3)',
                    'borderWidth' => 2,
                    'cornerRadius' => 10,
                    'padding' => 14,
                    'displayColors' => false,
                    'callbacks' => [
                        'title' => 'function(context) {
                            return context[0].label;
                        }',
                        'label' => 'function(context) {
                            let value = context.parsed.y;
                            let unit = "' . $unit . '";
                            return "Value: " + value.toFixed(2) + " " + unit;
                        }',
                    ],
                ],
                'legend' => [
                    'display' => false,
                ],
            ],
            'interaction' => [
                'intersect' => false,
                'mode' => 'nearest',
            ],
            'responsive' => true,
            'maintainAspectRatio' => false,
            'elements' => [
                'point' => [
                    'radius' => 4,
                    'hoverRadius' => 6,
                    'hoverBorderWidth' => 2,
                    'borderColor' => '#fff',
                ],
                'line' => [
                    'tension' => 0.4,
                    'borderWidth' => 3,
                    'borderCapStyle' => 'round',
                ],
            ],
            'scales' => [
                'y' => [
                    'beginAtZero' => true,
                    'display' => true,
                    'position' => 'left',
                    'title' => [
                        'display' => false,
                    ],
                    'grid' => [
                        'display' => true,
                        'color' => 'rgba(156, 163, 175, 0.08)',
                        'lineWidth' => 1,
                        'drawBorder' => false,
                    ],
                    'ticks' => [
                        'display' => true,
                        'color' => '#6B7280',
                        'font' => [
                            'size' => 11,
                            'weight' => '500',
                        ],
                        'maxTicksLimit' => 8,
                        'padding' => 8,
                        'stepSize' => match($this->filter) {
                            'orders' => 1,
                            default => null,
                        },
                        'precision' => match($this->filter) {
                            'orders' => 0,
                            default => 1,
                        },
                    ],
                ],
                'x' => [
                    'display' => true,
                    'grid' => [
                        'display' => false,
                    ],
                    'ticks' => [
                        'color' => '#6B7280',
                        'font' => [
                            'size' => 11,
                        ],
                        'maxRotation' => 0,
                        'minRotation' => 0,
                    ],
                ],
            ],
        ];
    }
}

