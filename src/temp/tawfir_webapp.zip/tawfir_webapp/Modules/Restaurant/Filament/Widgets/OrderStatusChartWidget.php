<?php

namespace Modules\Restaurant\Filament\Widgets;

use Filament\Widgets\ChartWidget;
use Modules\User\Entities\Order;
use Modules\User\Enums\OrderStatus;

class OrderStatusChartWidget extends ChartWidget
{
    protected static ?string $pollingInterval = null;
    
    public function getHeading(): ?string
    {
        $user = auth()->user();
        
        if ($user->restaurant ?? null) {
            return 'Today\'s Order Status';
        }
        
        return 'Today\'s Orders Status Overview';
    }
    
    public function getDescription(): ?string
    {
        return 'Showing orders from today only';
    }

    protected static ?int $sort = 3;

    protected int | string | array $columnSpan = 'full';

    protected static ?string $maxHeight = '300px';

    protected function getData(): array
    {
        $user = auth()->user();
        
        // Check if user has a restaurant (restaurant user) or is admin
        if ($user->restaurant ?? null) {
            $orders = Order::query()->where('restaurant_id', $user->restaurant->id);
        } else {
            // Admin user - show all orders across all restaurants
            $orders = Order::query();
        }
        
        // Only show today's orders
        $orders->whereDate('created_at', today());
        
        // Optimize: Get all counts in a single query using conditional aggregation
        $counts = $orders->selectRaw('
                SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) as incoming_count,
                SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) as ready_count,
                SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) as completed_count
            ', [
                OrderStatus::INCOMING->value,
                OrderStatus::READY->value,
                OrderStatus::COMPLETED->value
            ])
            ->first();
        
        $incoming = $counts->incoming_count ?? 0;
        $ready = $counts->ready_count ?? 0;
        $completed = $counts->completed_count ?? 0;
        
        $total = $incoming + $ready + $completed;
        
        // If no orders today, return empty state data
        if ($total === 0) {
            return [
                'datasets' => [
                    [
                        'label' => 'Orders',
                        'data' => [0, 0, 0],
                        'backgroundColor' => [
                            'rgba(156, 163, 175, 0.3)',
                            'rgba(156, 163, 175, 0.3)',
                            'rgba(156, 163, 175, 0.3)',
                        ],
                        'borderColor' => [
                            'rgba(156, 163, 175, 0.5)',
                            'rgba(156, 163, 175, 0.5)',
                            'rgba(156, 163, 175, 0.5)',
                        ],
                        'borderWidth' => 1,
                        'borderRadius' => 4,
                        'barThickness' => 35,
                    ],
                ],
                'labels' => [
                    'Incoming',
                    'Ready',
                    'Completed',
                ],
                'fulfillmentRate' => 0,
                'isEmpty' => true,
            ];
        }
        
        $fulfillmentRate = round(($completed / $total) * 100, 1);
        
        return [
            'datasets' => [
                [
                    'label' => 'Orders',
                    'data' => [$incoming, $ready, $completed],
                    'backgroundColor' => [
                        'rgba(59, 130, 246, 0.9)',   // Blue for incoming
                        'rgba(249, 115, 22, 0.9)',   // Orange for ready
                        'rgba(34, 197, 94, 0.9)',    // Green for completed
                    ],
                    'borderColor' => [
                        'rgba(59, 130, 246, 1)',   // Blue for incoming
                        'rgba(249, 115, 22, 1)',   // Orange for ready
                        'rgba(34, 197, 94, 1)',    // Green for completed
                    ],
                    'borderWidth' => 2,
                    'borderRadius' => 4,
                    'barThickness' => 35,
                ],
            ],
            'labels' => [
                'Incoming',
                'Ready',
                'Completed',
            ],
            'fulfillmentRate' => $fulfillmentRate,
        ];
    }

    protected function getType(): string
    {
        return 'bar';
    }

    protected function getFilters(): ?array
    {
        return null; // No time filter - always shows today's orders
    }

    protected function getOptions(): array
    {
        return [
            'animation' => [
                'duration' => 1000,
                'easing' => 'easeInOutQuart',
            ],
            'animations' => [
                'x' => [
                    'duration' => 1000,
                    'easing' => 'easeInOutQuart',
                ],
                'y' => [
                    'duration' => 1000,
                    'easing' => 'easeInOutQuart',
                ],
            ],
            'indexAxis' => 'y', // Horizontal bar chart
            'scales' => [
                'x' => [
                    'beginAtZero' => true,
                    'ticks' => [
                        'stepSize' => 1,
                        'precision' => 0,
                        'color' => '#6B7280',
                        'font' => [
                            'size' => 11,
                            'weight' => '500',
                        ],
                    ],
                    'grid' => [
                        'display' => true,
                        'color' => 'rgba(156, 163, 175, 0.08)',
                        'lineWidth' => 1,
                    ],
                ],
                'y' => [
                    'grid' => [
                        'display' => false,
                    ],
                    'ticks' => [
                        'color' => '#6B7280',
                        'font' => [
                            'size' => 12,
                            'weight' => '600',
                        ],
                    ],
                ],
            ],
            'plugins' => [
                'legend' => [
                    'display' => false,
                ],
                'tooltip' => [
                    'callbacks' => [
                        'title' => 'function(tooltipItems) {
                            return tooltipItems[0].label;
                        }',
                        'label' => 'function(context) {
                            let label = context.dataset.label || "";
                            if (label) {
                                label += ": ";
                            }
                            if (context.parsed.x !== null) {
                                label += context.parsed.x + " orders";
                            }
                            return label;
                        }',
                        'afterBody' => 'function(tooltipItems) {
                            const total = tooltipItems.reduce((sum, item) => sum + item.parsed.x, 0);
                            const completed = tooltipItems.find(item => item.label === "Completed")?.parsed.x || 0;
                            const rate = total > 0 ? ((completed / total) * 100).toFixed(1) : 0;
                            return ["Fulfillment Rate: " + rate + "%"];
                        }',
                    ],
                    'enabled' => true,
                    'backgroundColor' => 'rgba(17, 24, 39, 0.95)',
                    'titleColor' => '#F9FAFB',
                    'titleFont' => [
                        'size' => 13,
                        'weight' => '600',
                    ],
                    'bodyColor' => '#D1D5DB',
                    'bodyFont' => [
                        'size' => 13,
                    ],
                    'borderColor' => 'rgba(255, 255, 255, 0.1)',
                    'borderWidth' => 2,
                    'cornerRadius' => 10,
                    'padding' => 14,
                ],
            ],
            'interaction' => [
                'intersect' => false,
                'mode' => 'index',
            ],
        ];
    }
}

