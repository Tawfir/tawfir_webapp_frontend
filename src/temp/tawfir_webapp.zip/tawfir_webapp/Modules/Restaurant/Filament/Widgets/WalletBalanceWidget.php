<?php

namespace Modules\Restaurant\Filament\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Card;
use Modules\Payment\Services\WalletService;

class WalletBalanceWidget extends BaseWidget
{
    protected ?string $heading = 'Wallet Balance';

    protected function getCards(): array
    {
        $balance = WalletService::balance(auth()->user()->restaurant);

        return [
            Card::make('Current Balance', sprintf('$%0.2f', $balance)),
        ];
    }
}
