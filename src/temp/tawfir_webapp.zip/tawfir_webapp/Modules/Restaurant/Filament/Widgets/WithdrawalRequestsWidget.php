<?php

namespace Modules\Restaurant\Filament\Widgets;

use Filament\Widgets\TableWidget;
use Modules\Payment\Entities\WithdrawalRequest;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Actions\Action;
use Modules\Payment\Services\WalletService;
use Filament\Notifications\Notification;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\Relation;

class WithdrawalRequestsWidget extends TableWidget
{
    protected static ?string $heading = 'My Withdrawal Requests';
    
    protected static ?int $sort = 1;
    
    public function getTableHeading(): ?string
    {
        return 'My Withdrawal Requests';
    }
    
    protected int | string | array $columnSpan = [
        'md' => 2,
        'xl' => 2,
    ];

    protected function getTableQuery(): Builder|Relation|null
    {
        return WithdrawalRequest::query()
            ->where('restaurant_id', auth()->user()->restaurant->id)
            ->latest();
    }

    protected function getTableColumns(): array
    {
        return [
            TextColumn::make('id')->label('ID'),
            TextColumn::make('amount')->label('Amount')->money('usd'),
            TextColumn::make('status')->label('Status'),
            TextColumn::make('method')->label('Method'),
            TextColumn::make('created_at')
                ->label('Requested At')
                ->dateTime('d/m/Y H:i'),
        ];
    }

    protected function getTableHeaderActions(): array
    {
        return [
            Action::make('info')
                ->icon('heroicon-o-information-circle')
                ->color('gray')
                ->tooltip('Learn about withdrawal requests')
                ->modalHeading('About Withdrawal Requests')
                ->modalDescription('This widget tracks your withdrawal requests. When you click "Request Withdrawal", funds are transferred from your wallet (net earnings after 7.5% service fee) to your connected bank account. View the status of pending, approved, and completed withdrawals here.')
                ->modalSubmitAction(false)
                ->modalCancelActionLabel('Close'),
            
            Action::make('requestWithdrawal')
                ->label('Request Withdrawal')
                ->requiresConfirmation('Are you sure you want to withdraw your full balance?')
                ->action(function () {
                    $r = auth()->user()->restaurant;
                    $balance = WalletService::balance($r);

                    if ($balance <= 0) {
                        Notification::make()
                            ->danger()
                            ->title('No funds available')
                            ->body('Your wallet balance is zero, nothing to withdraw.')
                            ->send();

                        return;
                    }

                    try {
                        WithdrawalRequest::create([
                            'restaurant_id' => $r->id,
                            'amount'        => $balance,
                            'method'        => $r->payout_method,
                            'status'        => 'pending',
                        ]);

                        Notification::make()
                            ->success()
                            ->title('Withdrawal Requested')
                            ->body(sprintf('You have requested $%0.2f to be withdrawn.', $balance))
                            ->send();
                    } catch (\Throwable $e) {
                        Notification::make()
                            ->danger()
                            ->title('Request Failed')
                            ->body($e->getMessage())
                            ->send();
                    }
                }),
        ];
    }

    protected function getTableActions(): array
    {
        return []; // no per‐row actions
    }

    protected function getTableBulkActions(): array
    {
        return []; // no bulk actions
    }
}
