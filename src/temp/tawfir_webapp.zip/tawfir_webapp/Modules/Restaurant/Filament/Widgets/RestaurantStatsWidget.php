<?php

namespace Modules\Restaurant\Filament\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Card;
use Modules\User\Entities\Order;
use Modules\User\Entities\OrderItem;
use Modules\Payment\Services\WalletService;
use Illuminate\Support\Facades\DB;

class RestaurantStatsWidget extends BaseWidget
{
    protected ?string $heading = 'Your Restaurant at a Glance';

    protected function getCards(): array
    {
        $r         = auth()->user()->restaurant;
        $orders    = Order::query()->where('restaurant_id', $r->id);
        $completed = (clone $orders)->where('status', 'completed');

        // total CO₂ saved by completed orders
        $co2Saved = \DB::table('order_items')
            ->join('dishes', 'order_items.dish_id', '=', 'dishes.id')
            ->whereExists(function ($query) use ($r) {
                $query->selectRaw('1')
                    ->from('orders')
                    ->whereColumn('orders.id', 'order_items.order_id')
                    ->where('orders.restaurant_id', $r->id)
                    ->where('orders.status', 'completed');
            })
            ->selectRaw('SUM(order_items.quantity * dishes.co2_saved) AS total_co2')
            ->value('total_co2');

        return [
            Card::make('Total Orders', $orders->count()),
            Card::make('Incoming',     (clone $orders)->where('status','incoming')->count()),
            Card::make('Ready',        (clone $orders)->where('status','ready')->count()),
            Card::make('Completed',    $completed->count()),
            Card::make('Total Revenue', '$'.number_format($completed->sum('total_price'), 2)),
            Card::make('CO₂ Saved',     ($co2Saved ?? 0) . ' kg'),
            Card::make('Wallet Balance','$'.number_format(WalletService::balance($r), 2)),
        ];
    }
}
