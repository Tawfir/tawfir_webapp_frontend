<?php

namespace Modules\Restaurant\Filament\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Card;
use Modules\Restaurant\Entities\Dish;
use Modules\Payment\Services\WalletService;
use Modules\User\Entities\Order;
use Modules\User\Entities\OrderItem;
use Modules\User\Enums\OrderStatus;

class SurplusStatsWidget extends BaseWidget
{
    public function getHeading(): ?string
    {
        return 'Surplus Food Stats';
    }

    protected static ?int $sort = 1;

    protected int | string | array $columnSpan = [
        'md' => 2,
        'xl' => 2,
    ];

    protected function getCards(): array
    {
        $restaurant = auth()->user()->restaurant;
        
        // Total surplus (dishes with quantity > 0)
        $totalSurplus = Dish::where('restaurant_id', $restaurant->id)
            ->where('quantity', '>', 0)
            ->sum('quantity');
        
        // Revenue from surplus items (completed orders only)
        $totalRevenue = $restaurant->orders()
            ->where('status', 'completed')
            ->sum('total_price');
        
        $walletBalance = WalletService::balance($restaurant);
        
        // Calculate CO2 saved from completed orders
        $co2Saved = OrderItem::whereHas('order', function($query) use ($restaurant) {
            $query->where('restaurant_id', $restaurant->id)
                  ->where('status', OrderStatus::COMPLETED->value);
        })
        ->with('dish')
        ->get()
        ->sum(function($item) {
            return ($item->dish->co2_saved ?? 0) * $item->quantity;
        });
        
        // Calculate surplus items given away today (from completed orders today)
        $surplusItemsGivenToday = OrderItem::whereHas('order', function($query) use ($restaurant) {
            $query->where('restaurant_id', $restaurant->id)
                  ->where('status', OrderStatus::COMPLETED->value)
                  ->whereDate('created_at', today());
        })->sum('quantity');
        
        // Total surplus items available at start (we'll use total surplus items as a baseline)
        $totalItemsAvailable = $totalSurplus + $surplusItemsGivenToday;
        $surplusUtilization = $totalItemsAvailable > 0 ? round(($surplusItemsGivenToday / $totalItemsAvailable) * 100, 1) : 0;
        
        // Incoming orders today
        $incomingOrdersToday = $restaurant->orders()
            ->where('status', 'incoming')
            ->whereDate('created_at', today())
            ->count();
        
        return [
            Card::make('Total Surplus Items', $totalSurplus . ' items')
                ->description('Currently available')
                ->descriptionIcon('heroicon-o-shopping-bag')
                ->color('success'),
            Card::make('Revenue from Surplus', '$' . number_format($totalRevenue, 2))
                ->description('Total earnings')
                ->descriptionIcon('heroicon-o-currency-dollar')
                ->color('success'),
            Card::make('Wallet Balance', '$' . number_format($walletBalance, 2))
                ->description('Net earnings after service fees')
                ->descriptionIcon('heroicon-o-wallet')
                ->color('success'),
            Card::make('Total CO₂ Saved', number_format($co2Saved, 2) . ' kg')
                ->description('From completed orders')
                ->descriptionIcon('heroicon-o-globe-alt')
                ->color('success'),
            Card::make('Surplus Utilization Today', $surplusUtilization . '%')
                ->description("{$surplusItemsGivenToday} of {$totalItemsAvailable} items given")
                ->descriptionIcon('heroicon-o-check-circle')
                ->color('success'),
            Card::make('Incoming Orders Today', $incomingOrdersToday)
                ->description('New orders today')
                ->descriptionIcon('heroicon-o-inbox')
                ->color('warning'),
        ];
    }
}

