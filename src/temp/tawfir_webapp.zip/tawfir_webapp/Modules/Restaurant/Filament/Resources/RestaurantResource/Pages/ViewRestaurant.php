<?php

namespace Modules\Restaurant\Filament\Resources\RestaurantResource\Pages;

use Filament\Resources\Pages\ViewRecord;
use Modules\Restaurant\Filament\Resources\RestaurantResource;

class ViewRestaurant extends ViewRecord
{
    protected static string $resource = RestaurantResource::class;
}
