<?php

namespace Modules\Restaurant\Filament\Resources\RestaurantResource\Pages;

use Filament\Resources\Pages\ListRecords;
use Modules\Restaurant\Filament\Resources\RestaurantResource;

class ListRestaurants extends ListRecords
{
    protected static string $resource = RestaurantResource::class;
    public function mount(): void
    {
        $id = auth()->user()->restaurant->id;
        $this->redirect(static::getResource()::getUrl('edit', ['record' => $id]));
    }
}
