<?php

namespace Modules\Restaurant\Filament\Resources\OrderResource\Pages;


use Filament\Forms\Components\Select;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ViewRecord;
use Filament\Infolists\Components\Section;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Infolist;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Services\WalletService;
use Modules\Restaurant\Filament\Resources\OrderResource;
use Filament\Actions\Action;
use Filament\Forms\Form;
use Illuminate\Support\Facades\Http;

class ViewOrder extends ViewRecord
{
    protected static string $resource = OrderResource::class;

    public function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->record($this->record)
            ->schema([
                Section::make('Order Summary')->schema([
                    TextEntry::make('id')->label('Order #'),
                    TextEntry::make('user.name')->label('Customer'),
                    TextEntry::make('total_price')->label('Total Price')->money('USD'),
                    TextEntry::make('status')
                        ->badge()
                        ->colors([
                            'incoming' => 'info',
                            'ready' => 'warning',
                            'completed' => 'success',
                        ]),
                    TextEntry::make('pickup_time')->label('Pickup Time')->time('H:i'),
                    TextEntry::make('created_at')->label('Created At')->dateTime('d/m/Y H:i'),
                ]),
            ]);
    }
    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('status')
                    ->label('Update Order Status')
                    ->options([
                        'incoming' => 'Incoming',
                        'ready' => 'Ready',
                        'completed' => 'Completed',
                    ])
                    ->required()
                    ->default($this->record->status),
            ]);
    }
    protected function getHeaderActions(): array
    {
        return [
            Action::make('updateStatus')
                ->label('Change Order Status')
                // only show if not already completed:
                ->visible(fn (): bool => $this->record->status !== 'completed')
                ->form([
                    Select::make('status')
                        ->label('Status')
                        ->options([
                            'incoming'  => 'Incoming',
                            'ready'     => 'Ready',
                            'completed' => 'Completed',
                        ])
                        ->required()
                        ->default($this->record->status),
                ])
                ->action(function (array $data): void {
                    $order      = $this->record;
                    $oldStatus  = $order->status;
                    $newStatus  = $data['status'];

                    $order->update(['status' => $newStatus]);

                    // Only run settlement logic once, when going to 'completed'
                    if ($oldStatus !== 'completed' && $newStatus === 'completed') {
                        // Check if wallet already credited for this order
                        $alreadyCredited = \Modules\Payment\Entities\WalletTransaction::where('order_id', $order->id)
                            ->where('type', 'credit')
                            ->exists();

                        if (!$alreadyCredited) {
                            // Compute net amount (after 7.5% service fee)
                            $total    = $order->total_price;
                            $feePct   = config('payment.service_fee_percent', 7.5);
                            $service  = ($total * $feePct) / 100;
                            $net      = $total - $service;

                            // Get the transaction to determine payment method
                            $txn = Transaction::where('order_id', $order->id)->first();
                            $paymentMethod = $txn ? $txn->method : 'unknown';

                            // Credit the restaurant's wallet
                            WalletService::credit(
                                $order->restaurant,
                                $net,
                                "Order #{$order->id} ({$paymentMethod})",
                                $order->id
                            );

                            // If it's a cash transaction, mark it as succeeded
                            if ($txn && $txn->method === 'cash') {
                                $txn->update(['status' => 'succeeded']);
                            }
                        }
                    }

                    // 4️⃣ Send push notification to customer
                    // (your existing OneSignal code)
                    //Http::withHeaders([
                    //    'Authorization' => 'Basic '.config('services.onesignal.rest_api_key'),
                    //    'Content-Type'  => 'application/json',
                    //])->post('https://onesignal.com/api/v1/notifications', [
                    //    'app_id'                    => config('services.onesignal.app_id'),
                    //    'include_external_user_ids'=> [$order->user_id],
                    //    'headings'                 => ['en' => 'Order #'.$order->id.' is '.$newStatus],
                    //    'contents'                 => ['en' => "Your order status is now {$newStatus}."],
                    //]);
                    Notification::make()
                        ->title('Order status updated!')
                        ->success()
                        ->send();
                }),
        ];
    }
    protected function getFooterActions(): array
    {
        return [
            Action::make('updateStatus')
                ->label('Update Status')
                ->color('primary')
                // hide once it’s completed
                ->visible(fn (): bool => $this->record->status !== 'completed')
                ->action(function () {
                    $this->record->update([
                        'status' => $this->form->getState()['status'],
                    ]);

                    // Send push notification (replace with actual OneSignal logic)
                    Http::withHeaders([
                        'Authorization' => 'Basic ' . config('services.onesignal.rest_api_key'),
                        'Content-Type' => 'application/json',
                    ])->post('https://onesignal.com/api/v1/notifications', [
                        'app_id' => config('services.onesignal.app_id'),
                        'include_external_user_ids' => [$this->record->user_id],
                        'headings' => ['en' => 'Order Status Updated'],
                        'contents' => ['en' => "Your order #{$this->record->id} is now {$this->record->status}."],
                    ]);

                    $this->notify('success', 'Order status updated and notification sent!');
                }),
        ];
    }

}


