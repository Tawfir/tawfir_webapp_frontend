<?php

namespace Modules\Restaurant\Filament\Resources\OrderResource\RelationManagers;

use Filament\Forms;
use Filament\Tables;
use Filament\Forms\Form;
use Filament\Tables\Table;
use Filament\Resources\RelationManagers\RelationManager;
use Illuminate\Database\Eloquent\Builder;

class OrderItemsRelationManager extends RelationManager
{
    protected static string $relationship = 'items';

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('dish.name')
                ->label('Dish')
                ->disabled()
                ->dehydrated(false),

            Forms\Components\TextInput::make('quantity')
                ->numeric()
                ->disabled(),
            Forms\Components\TextInput::make('dish.pickup_time')
                ->label('Pickup Time')
                ->numeric()
                ->disabled(),

            Forms\Components\TextInput::make('price_at_order_time')
                ->numeric()
                ->prefix('USD')
                ->disabled(),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('dish.name')->label('Dish'),
                Tables\Columns\TextColumn::make('quantity'),
                Tables\Columns\TextColumn::make('dish.pickup_time')->time('H:i'),
                Tables\Columns\TextColumn::make('price_at_order_time')->money('USD'),
            ])
            ->headerActions([]) // prevent creation from panel
            ->actions([])
            ->bulkActions([]);
    }
}
