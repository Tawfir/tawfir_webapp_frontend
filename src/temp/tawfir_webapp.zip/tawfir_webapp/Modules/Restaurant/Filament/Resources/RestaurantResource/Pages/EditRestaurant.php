<?php

namespace Modules\Restaurant\Filament\Resources\RestaurantResource\Pages;

use Filament\Actions\Action;
use Filament\Resources\Pages\EditRecord;
use Modules\Restaurant\Entities\Restaurant;
use Modules\Restaurant\Services\StripeAccountService;
use Modules\Restaurant\Filament\Resources\RestaurantResource;

class EditRestaurant extends EditRecord
{
    protected static string $resource = RestaurantResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Action::make('connectStripe')
                ->label('Connect with Stripe')
                ->visible(fn () =>
                    $this->record->payout_method === 'stripe'
                    && ! $this->record->stripe_account_id
                )
                ->action(function () {
                    $svc = app(StripeAccountService::class);
                    $svc->createConnectAccount($this->record);
                    $url = $svc->createOnboardingLink($this->record);
                    $this->redirect($url);
                }),

            Action::make('finishStripe')
                ->label('Finish Stripe Setup')
                ->color('warning')
                ->visible(fn () =>
                    $this->record->payout_method === 'stripe'
                    && $this->record->stripe_account_id
                    && ! $this->record->stripe_account_details_submitted
                )
                ->action(function () {
                    $url = app(StripeAccountService::class)
                        ->createOnboardingLink($this->record);
                    $this->redirect($url);
                }),
            Action::make('manageStripe')
                ->label('Manage Stripe Account')
                ->icon('heroicon-o-home')    // pick an icon you like
                ->visible(fn (): bool =>
                    $this->record->payout_method === 'stripe' &&
                    (bool) $this->record->stripe_account_id
                    && $this->record->stripe_account_details_submitted
                )
                ->url(fn () => app(StripeAccountService::class)
                    ->createLoginLink($this->record))
                ->openUrlInNewTab(),
        ];
    }
}
