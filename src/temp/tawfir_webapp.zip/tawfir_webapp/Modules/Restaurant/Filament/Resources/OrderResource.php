<?php

namespace Modules\Restaurant\Filament\Resources;

use Modules\Restaurant\Filament\Resources\OrderResource\Pages\ViewOrder;
use Modules\Restaurant\Filament\Resources\OrderResource\Pages;
use Modules\Restaurant\Filament\Resources\OrderResource\Pages\ListOrders;
use Modules\Restaurant\Filament\Resources\OrderResource\RelationManagers;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Modules\Restaurant\Filament\Resources\OrderResource\RelationManagers\OrderItemsRelationManager;
use Modules\User\Entities\Order;

class OrderResource extends Resource
{
    protected static ?string $model = Order::class;
    protected static ?string $modelLabel = 'Orders';
    protected static ?string $pluralModelLabel = 'Orders';

    protected static ?string $navigationGroup = 'Orders';
    protected static ?string $navigationLabel = 'Order History';

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                //
            ]);
    }
    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->where('restaurant_id', auth()->user()->restaurant->id)
            ->orderBy('created_at', 'desc');
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')
                    ->label('Order #')
                    ->sortable(),
                Tables\Columns\TextColumn::make('user.name')
                    ->label('Customer')
                    ->searchable(),
                Tables\Columns\TextColumn::make('total_price')
                    ->money('USD')
                    ->sortable(),
                Tables\Columns\TextColumn::make('status')
                    ->badge()
                    ->colors([
                        'incoming' => 'info',
                        'ready' => 'warning',
                        'completed' => 'success',
                    ])
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime('d/m/Y H:i')
                    ->label('Date')
                    ->sortable(),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make()->hidden(),
            ])
            ->filters([
                Tables\Filters\Filter::make('order_id')
                    ->form([
                        Forms\Components\TextInput::make('order_id')
                            ->label('Order #')
                            ->placeholder('Enter order number')
                            ->numeric(),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['order_id'],
                                fn (Builder $query, $orderId): Builder => $query->where('id', $orderId),
                            );
                    }),
                Tables\Filters\SelectFilter::make('status')
                    ->options([
                        'incoming' => 'Incoming',
                        'ready' => 'Ready',
                        'completed' => 'Completed',
                    ]),
                Tables\Filters\Filter::make('created_at')
                    ->form([
                        Forms\Components\DatePicker::make('created_from')
                            ->label('From Date'),
                        Forms\Components\DatePicker::make('created_until')
                            ->label('Until Date'),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['created_from'],
                                fn (Builder $query, $date): Builder => $query->whereDate('created_at', '>=', $date),
                            )
                            ->when(
                                $data['created_until'],
                                fn (Builder $query, $date): Builder => $query->whereDate('created_at', '<=', $date),
                            );
                    }),
            ])
            ->defaultSort('created_at', 'desc');
    }


    public static function getRelations(): array
    {
        return [
            OrderItemsRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListOrders::route('/'),
            'view' => ViewOrder::route('/{record}'), // ✅ this must match the correct class
            ];
    }
    public static function canCreate(): bool
    {
        return false;
    }

    public static function canEdit(Order|\Illuminate\Database\Eloquent\Model $record): bool
    {
        return false;
    }

    public static function canDelete(Order|\Illuminate\Database\Eloquent\Model $record): bool
    {
        return false;
    }


}
