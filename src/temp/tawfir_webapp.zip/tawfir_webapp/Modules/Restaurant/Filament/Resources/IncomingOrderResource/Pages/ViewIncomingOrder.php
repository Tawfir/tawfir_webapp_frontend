<?php

namespace Modules\Restaurant\Filament\Resources\IncomingOrderResource\Pages;

use Modules\Restaurant\Filament\Resources\IncomingOrderResource;
use Filament\Resources\Pages\ViewRecord;
use Filament\Infolists\Components\Section;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Infolist;
use Filament\Actions\Action;
use Filament\Notifications\Notification;

class ViewIncomingOrder extends ViewRecord
{
    protected static string $resource = IncomingOrderResource::class;

    public function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->record($this->record)
            ->schema([
                Section::make('Order Summary')->schema([
                    TextEntry::make('id')->label('Order #'),
                    TextEntry::make('user.name')->label('Customer'),
                    TextEntry::make('total_price')->label('Total Price')->money('USD'),
                    TextEntry::make('status')
                        ->badge()
                        ->colors([
                            'incoming' => 'info',
                            'ready' => 'warning',
                            'completed' => 'success',
                        ]),
                    TextEntry::make('pickup_time')->label('Pickup Time')->time('H:i'),
                    TextEntry::make('created_at')->label('Created At')->dateTime('d/m/Y H:i'),
                ]),
            ]);
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('mark_as_ready')
                ->label('Mark as Ready')
                ->icon('heroicon-o-check-circle')
                ->color('warning')
                ->action(function () {
                    $this->record->update(['status' => 'ready']);
                    
                    Notification::make()
                        ->title('Order #' . $this->record->id . ' marked as ready')
                        ->success()
                        ->send();
                    
                    $this->redirect(static::getResource()::getUrl('index'));
                })
                ->requiresConfirmation()
                ->modalHeading('Mark Order as Ready')
                ->modalDescription('Are you sure this order is ready for pickup?')
                ->modalSubmitActionLabel('Yes, Mark as Ready'),
        ];
    }
}

