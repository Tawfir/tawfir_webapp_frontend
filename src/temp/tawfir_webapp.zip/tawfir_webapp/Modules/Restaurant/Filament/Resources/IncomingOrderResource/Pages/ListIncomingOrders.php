<?php

namespace Modules\Restaurant\Filament\Resources\IncomingOrderResource\Pages;

use Modules\Restaurant\Filament\Resources\IncomingOrderResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListIncomingOrders extends ListRecords
{
    protected static string $resource = IncomingOrderResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}

