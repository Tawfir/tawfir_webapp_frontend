<?php

namespace Modules\Restaurant\Filament\Resources;

use Modules\Restaurant\Filament\Resources\IncomingOrderResource\Pages;
use Modules\User\Entities\Order;
use Filament\Forms;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Tables\Actions\Action;
use Filament\Notifications\Notification;
use Illuminate\Database\Eloquent\Builder;

class IncomingOrderResource extends Resource
{
    protected static ?string $model = Order::class;
    protected static ?string $modelLabel = 'Incoming Order';
    protected static ?string $pluralModelLabel = 'Incoming Orders';
    protected static ?string $navigationGroup = 'Orders';
    protected static ?string $navigationLabel = 'Incoming Orders';
    protected static ?string $navigationIcon = 'heroicon-o-inbox';
    protected static ?string $slug = 'incoming-orders';

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->where('restaurant_id', auth()->user()->restaurant->id)
            ->where('status', 'incoming')
            ->orderBy('created_at', 'desc');
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')
                    ->label('Order #')
                    ->sortable(),
                Tables\Columns\TextColumn::make('user.name')
                    ->label('Customer')
                    ->searchable(),
                Tables\Columns\TextColumn::make('total_price')
                    ->money('USD')
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime('d/m/Y H:i')
                    ->label('Date')
                    ->sortable(),
            ])
            ->actions([
                Action::make('mark_as_ready')
                    ->label('Mark as Ready')
                    ->icon('heroicon-o-check-circle')
                    ->color('warning')
                    ->action(function (Order $record) {
                        $record->update(['status' => 'ready']);
                        
                        Notification::make()
                            ->title('Order #' . $record->id . ' marked as ready')
                            ->success()
                            ->send();
                    })
                    ->requiresConfirmation()
                    ->modalHeading('Mark Order as Ready')
                    ->modalDescription('Are you sure this order is ready for pickup?')
                    ->modalSubmitActionLabel('Yes, Mark as Ready'),
                Tables\Actions\ViewAction::make(),
            ])
            ->filters([
                Tables\Filters\Filter::make('order_id')
                    ->form([
                        Forms\Components\TextInput::make('order_id')
                            ->label('Order #')
                            ->placeholder('Enter order number')
                            ->numeric(),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['order_id'],
                                fn (Builder $query, $orderId): Builder => $query->where('id', $orderId),
                            );
                    }),
                Tables\Filters\Filter::make('created_at')
                    ->form([
                        Forms\Components\DatePicker::make('created_from')
                            ->label('From Date'),
                        Forms\Components\DatePicker::make('created_until')
                            ->label('Until Date'),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['created_from'],
                                fn (Builder $query, $date): Builder => $query->whereDate('created_at', '>=', $date),
                            )
                            ->when(
                                $data['created_until'],
                                fn (Builder $query, $date): Builder => $query->whereDate('created_at', '<=', $date),
                            );
                    }),
            ])
            ->defaultSort('created_at', 'desc');
    }

    public static function canCreate(): bool
    {
        return false;
    }

    public static function canEdit($record): bool
    {
        return false;
    }

    public static function canDelete($record): bool
    {
        return false;
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListIncomingOrders::route('/'),
            'view' => Pages\ViewIncomingOrder::route('/{record}'),
        ];
    }
}

