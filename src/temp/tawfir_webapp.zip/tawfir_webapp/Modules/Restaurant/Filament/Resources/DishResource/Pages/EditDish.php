<?php

namespace Modules\Restaurant\Filament\Resources\DishResource\Pages;

use Filament\Actions;
use Filament\Resources\Pages\EditRecord;
use Modules\Restaurant\Filament\Resources\DishResource;

class EditDish extends EditRecord
{
    protected static string $resource = DishResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
