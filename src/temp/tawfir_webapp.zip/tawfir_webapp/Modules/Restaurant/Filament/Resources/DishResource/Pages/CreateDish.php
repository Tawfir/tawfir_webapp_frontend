<?php

namespace Modules\Restaurant\Filament\Resources\DishResource\Pages;

use Filament\Resources\Pages\CreateRecord;
use Modules\Restaurant\Filament\Resources\DishResource;

class CreateDish extends CreateRecord
{
    protected static string $resource = DishResource::class;

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $data['restaurant_id'] = auth()->user()->restaurant->id;
        return $data;
    }
}
