<?php

namespace Modules\Restaurant\Filament\Resources\DishResource\Pages;

use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
use Modules\Restaurant\Filament\Resources\DishResource;

class ListDishes extends ListRecords
{
    protected static string $resource = DishResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
