<?php

namespace Modules\Restaurant\Filament\Resources\OrderResource\Pages;

use Modules\Restaurant\Filament\Resources\OrderResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOrder extends CreateRecord
{
    protected static string $resource = OrderResource::class;
}
