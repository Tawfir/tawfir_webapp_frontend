<?php

namespace Modules\Restaurant\Filament\Resources;

use Cheesegrits\FilamentGoogleMaps\Fields\Map;
use Filament\Tables\Actions\EditAction;
use Modules\Restaurant\Entities\Restaurant;
use Filament\Resources\Resource;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Illuminate\Database\Eloquent\Builder;
use Modules\Restaurant\Filament\Resources\RestaurantResource\Pages\EditRestaurant;
use Modules\Restaurant\Filament\Resources\RestaurantResource\Pages\ListRestaurants;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\TimePicker;
use Filament\Forms\Components\MultiSelect;
use Filament\Forms\Components\FileUpload;
use Illuminate\Support\HtmlString;
use Filament\Forms\Components\Placeholder;

class RestaurantResource extends Resource
{
    protected static ?string $model = Restaurant::class;
    protected static ?string $navigationIcon = 'heroicon-o-building-office';
    protected static ?string $navigationGroup = 'Restaurant Management';
    protected static ?string $modelLabel = 'Restaurant Profile';
    protected static ?string $pluralModelLabel = 'Restaurant Profile';

    public static function canViewAny(): bool
    {
        return true;
    }

    public static function shouldRegisterNavigation(): bool
    {
        return \Filament\Facades\Filament::getCurrentPanel()?->getId() === 'restaurant';
    }

    public static function canCreate(): bool
    {
        return false;
    }

    public static function canDelete($record): bool
    {
        return false;
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->where('id', auth()->user()->restaurant->id);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')->label('ID')->sortable(),
                TextColumn::make('name')->label('Name'),
                TextColumn::make('address')->label('Address'),
                TextColumn::make('payout_method')
                    ->label('Payout Method')
                    ->formatStateUsing(fn (string $state) => match ($state) {
                        'manual' => 'Manual Bank Transfer',
                        'stripe' => 'Stripe Connect',
                        default  => $state,
                    }),
            ])
            ->actions([
                EditAction::make(),
            ])
            ->bulkActions([]);
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->label('Restaurant Name')
                    ->required(),

                TextInput::make('address')
                    ->label('Address')
                    ->required(),
                Placeholder::make('use_location')
                    ->columnSpan('full')
                    ->content(new HtmlString(<<<'HTML'
<button
    type="button"
    x-data
    x-on:click="
        navigator.geolocation.getCurrentPosition(
            position => {
                $wire.set('data.lat', position.coords.latitude);
                $wire.set('data.lng', position.coords.longitude);
            },
            error => alert('Geolocation failed: ' + error.message)
        )
    "
 class="
      inline-flex items-center justify-center
      w-full
      px-4 py-2
      text-sm font-medium
      rounded-lg
      bg-primary-600 hover:bg-primary-700
      text-white
      focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500
    ">
    Use my current location
</button>
HTML
                    )),

                Map::make('location')
                    ->label('Pick on Map')
                    ->reactive()
                    ->afterStateUpdated(function (array $state, callable $get, callable $set) {
                        $set('lat', $state['lat']);
                        $set('lng', $state['lng']);
                    })
                    ->defaultLocation([
                        'lat' => 30.0444,  // Cairo center fallback
                        'lng' => 31.2357,
                    ])
                    ->draggable()
                    ->clickable()
                    ->columnSpan('full'),



                TextInput::make('lat')
                    ->label('Latitude')
                    ->reactive()
                    ->afterStateUpdated(function (float $state, callable $get, callable $set) {
                        $set('location', [
                            'lat' => (float) $state,
                            'lng' => (float) $get('lng'),
                        ]);
                    })
                    ->required()
                    ->numeric()
                    ->lazy(),

                TextInput::make('lng')
                    ->label('Longitude')
                    ->reactive()
                    ->afterStateUpdated(function (float $state, callable $get, callable $set) {
                        $set('location', [
                            'lat' => (float) $get('lat'),
                            'lng' => (float) $state,
                        ]);
                    })
                    ->required()
                    ->numeric()
                    ->lazy(),
                Select::make('payout_method')
                    ->label('Payout Method')
                    ->options([
                        'manual' => 'Manual Bank Transfer',
                        'stripe' => 'Stripe Connect',
                    ])
                    ->default('manual')
                    ->required(),

                // Working hours JSON array
                Repeater::make('working_hours')
                    ->label('Working Hours')
                    ->columns(3)
                    ->schema([
                        Select::make('day')
                            ->label('Day')
                            ->options([
                                'monday'    => 'Monday',
                                'tuesday'   => 'Tuesday',
                                'wednesday' => 'Wednesday',
                                'thursday'  => 'Thursday',
                                'friday'    => 'Friday',
                                'saturday'  => 'Saturday',
                                'sunday'    => 'Sunday',
                            ])
                            ->required(),
                        TimePicker::make('open')
                            ->label('Opens At')
                            ->withoutSeconds()
                            ->required(),
                        TimePicker::make('close')
                            ->label('Closes At')
                            ->withoutSeconds()
                            ->required(),
                    ])
                    ->defaultItems(7)
                    ->minItems(1)
                    ->columnSpan('full'),

                TextInput::make('public_phone')
                    ->label('Public Phone')
                    ->required(),

                TextInput::make('private_phone')
                    ->label('Private Phone')
                    ->required(),

                Select::make('food_category_ids')
                    ->label('Food Categories')
                    ->relationship('categories', 'name')
                    ->multiple()
                    ->preload()
                    ->required(),

                FileUpload::make('place_pics')
                    ->label('Place Pictures')
                    ->image()
                    ->multiple()
                    ->maxFiles(5)
                    ->directory('restaurants/place-pics'),

                FileUpload::make('profile_pic')
                    ->label('Profile Picture')
                    ->image()
                    ->directory('restaurants/profile-pics'),

                FileUpload::make('cover_image')
                    ->label('Cover Image')
                    ->image()
                    ->directory('restaurants/cover-images'),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListRestaurants::route('/'),
            'edit'  => EditRestaurant::route('/{record}/edit'),
            ];
    }
    public static function getNavigationPath(): string
    {
        $id = auth()->user()->restaurant->id;

        // This path is relative to the panel prefix (/restaurant),
        // so it becomes: /restaurant/restaurants/{id}/edit
        return "/restaurants/{$id}/edit";
    }


}
