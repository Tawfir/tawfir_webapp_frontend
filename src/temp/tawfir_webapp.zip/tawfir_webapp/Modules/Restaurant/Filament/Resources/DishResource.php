<?php

namespace Modules\Restaurant\Filament\Resources;

use Filament\Forms;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TimePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Forms\Form;
use Modules\Restaurant\Entities\Dish;
use Modules\Restaurant\Enums\DishAvailabilityMethod;
use Modules\Restaurant\Filament\Resources\DishResource\Pages\CreateDish;
use Modules\Restaurant\Filament\Resources\DishResource\Pages\EditDish;
use Modules\Restaurant\Filament\Resources\DishResource\Pages\ListDishes;

class DishResource extends Resource
{
    protected static ?string $model = Dish::class;
    protected static ?string $modelLabel = 'Dish';
    protected static ?string $pluralModelLabel = 'Dishes';
    protected static ?string $navigationGroup = 'Dishes';

    public static function getNavigationIcon(): ?string
    {
        return 'heroicon-o-fire';
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->required()
                    ->maxLength(255)
                    ->placeholder('Enter dish name'),
                Forms\Components\Textarea::make('description')
                    ->maxLength(500)
                    ->placeholder('Enter dish description'),


                FileUpload::make('image')
                    ->image()
                    ->directory('dishes')
                    ->disk('public')
                    ->required(),

                Select::make('categories')
                    ->label('Categories')
                    ->multiple()
                    ->preload()
                    ->relationship('categories', 'name')
                    ->required(),





                TextInput::make('price')
                    ->label('List Price')
                    ->reactive()
                    ->numeric()
                    ->prefix('$')
                    ->step(0.01)
                    ->afterStateUpdated(function ($state, $set, $get) {
                        $discount     = $get('discount')     ?? 0;
                        $type         = $get('discount_type') ?? 'amount';
                        $price        = $state;
                        $discounted   = $type === 'percent'
                            ? $price * (1 - $discount / 100)
                            : $price - $discount;
                        $set('discounted_price', round($discounted, 2));
                    }),

                Select::make('discount_type')
                    ->label('Discount Type')
                    ->options([
                        'amount'  => 'Fixed Amount',
                        'percent' => 'Percentage',
                    ])
                    ->reactive()
                    ->default('amount')
                    ->afterStateUpdated(function ($state, $set, $get) {
                        $price      = $get('price')    ?? 0;
                        $discount   = $get('discount') ?? 0;
                        $discounted = $state === 'percent'
                            ? $price * (1 - $discount / 100)
                            : $price - $discount;
                        $set('discounted_price', round($discounted, 2));
                    }),
                TextInput::make('discount')
                    ->label('Discount')
                    ->reactive()
                    ->numeric()
                    ->afterStateUpdated(function ($state, $set, $get) {
                        // Recalculate when discount amount changes
                        $price = $get('price') ?? 0;
                        $type = $get('discount_type') ?? 'amount';
                        if ($type === 'percent') {
                            $discounted = $price * (1 - ($state / 100));
                        } else {
                            $discounted = $price - $state;
                        }
                        $set('discounted_price', round($discounted, 2));
                    }),
                TextInput::make('discounted_price')
                    ->label('Discounted Price')
                    ->readOnly()
                    ->numeric()
                    ->prefix('$')
                    ->step(0.01),
                TextInput::make('co2_saved')
                    ->label('CO2 Saved (kg)')
                    ->numeric()
                    ->step(0.01),

                TimePicker::make('pickup_time')
                    ->label('Pickup Time')
                    ->required()
                    ->withoutSeconds(),

                Select::make('availability_method')
                    ->options(DishAvailabilityMethod::options())
                    ->required(),

                TextInput::make('quantity')
                    ->numeric()
                    ->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('image')
                    ->disk('public')
                    ->visibility('public')
                    ->url(fn ($record) => \Storage::disk('public')->url($record->image)),

                Tables\Columns\TextColumn::make('name')->searchable(),

                Tables\Columns\TextColumn::make('price')
                    ->label('List Price')
                    ->money('USD', true),

                Tables\Columns\TextColumn::make('discounted_price')
                    ->label('Discounted Price')
                    ->money('USD', true),

                Tables\Columns\TextColumn::make('quantity'),

                Tables\Columns\TextColumn::make('pickup_time')
                    ->label('Pickup Time')
                    ->time('H:i'),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->filters([]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListDishes::route('/'),
            'create' => CreateDish::route('/create'),
            'edit' => EditDish::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): \Illuminate\Database\Eloquent\Builder
    {
        return parent::getEloquentQuery()
            ->where('restaurant_id', auth()->user()->restaurant->id);
            //->whereDate('created_at', today());
    }

    public static function beforeCreate(array $data): array
    {
        $data['restaurant_id'] = auth()->user()->restaurant->id;

        return $data;
    }
}
