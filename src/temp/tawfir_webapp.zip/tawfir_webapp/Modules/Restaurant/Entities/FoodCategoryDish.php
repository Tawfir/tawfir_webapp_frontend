<?php

namespace Modules\Restaurant\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class FoodCategoryDish extends Model
{
    protected $table = 'food_category_dish';
   protected $guarded = [];
}
