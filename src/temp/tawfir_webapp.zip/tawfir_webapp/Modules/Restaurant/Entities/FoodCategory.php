<?php

namespace Modules\Restaurant\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Str;

class FoodCategory extends Model
{
    protected $fillable = ['name', 'slug','cover','image'];
    protected $appends = [
        'image_url',
        'cover_url',
    ];

    protected static function booted()
    {
        static::saving(function ($category) {
            $category->slug = Str::slug(
                $category->slug ?: $category->name
            );
        });
    }
    public function restaurants()
    {
        return $this->belongsToMany(Restaurant::class, 'food_category_restaurant');
    }


    public function dishes()
    {
        return $this->belongsToMany(
            Dish::class,
            'food_category_dish',
        );
    }

    // NEW: return full URL, leave raw `image` column untouched
    public function getImageUrlAttribute(): ?string
    {
        return $this->attributes['image']
            ? asset("storage/{$this->attributes['image']}")
            : null;
    }

    // NEW: return full URL, leave raw `cover` column untouched
    public function getCoverUrlAttribute(): ?string
    {
        return $this->cover
            ? asset("storage/{$this->cover}")
            : null;
    }
}
