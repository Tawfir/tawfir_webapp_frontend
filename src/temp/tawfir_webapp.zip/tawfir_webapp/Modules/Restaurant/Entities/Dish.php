<?php

namespace Modules\Restaurant\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Restaurant\Enums\DishAvailabilityMethod;

class Dish extends Model
{
    protected $fillable = [
        'restaurant_id',
        'name',
        'image',
        'price',
        'discounted_price',
        'description',
        'co2_saved',
        'pickup_time',
        'availability_method',
        'quantity',
    ];

    protected $casts = [
        'availability_method' => DishAvailabilityMethod::class,
        'pickup_time' => 'datetime:H:i',
        'co2_saved'           => 'decimal:2',    // ← always two decimal places
        ];
    protected int $jsonSerializeOptions = JSON_PRESERVE_ZERO_FRACTION;

    protected $appends = ['image_url'];

    public function restaurant()
    {
        return $this->belongsTo(Restaurant::class);
    }

    public function categories()
    {
        return $this->belongsToMany(
            FoodCategory::class,
            'food_category_dish',
        );
    }

    public function orders()
    {
        return $this->hasMany(\Modules\User\Entities\OrderItem::class, 'dish_id');
    }

    public function getImageUrlAttribute(): ?string
    {
        return $this->image
            ? asset("storage/{$this->image}")
            : null;
    }

    


}
