<?php

namespace Modules\Restaurant\Entities;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Payment\Entities\WalletTransaction;
use Modules\Payment\Entities\WithdrawalRequest;
use Modules\Restaurant\Enums\RestaurantStatus;

class Restaurant extends Model
{
    use HasFactory;

    protected $guarded = [];
    protected $appends = [
        'profile_pic_url',
        'cover_image_url',
        'place_pics_urls',
        'location'
    ];

    protected $casts = [
        'lat'            => 'float',
        'lng'            => 'float',
        'place_pics'     => 'array',
        'working_hours'  => 'array',
        'status' => RestaurantStatus::class,
    ];

// this tells Eloquent how to read ->location
    public function getLocationAttribute(): array
    {
        return [
            'lat' => $this->lat   ?? 0.0,
            'lng' => $this->lng   ?? 0.0,
        ];
    }

    public function setLocationAttribute(array $value): void
    {
        $this->lat = $value['lat'] ?? null;
        $this->lng = $value['lng'] ?? null;
    }
    public function categories()
    {
        return $this->belongsToMany(FoodCategory::class, 'food_category_restaurant');
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function dishes()
    {
        return $this->hasMany(Dish::class);
    }

    public function orders()
    {
        return $this->hasMany(\Modules\User\Entities\Order::class);
    }

    public function walletTransactions()
    {
        return $this->morphMany(WalletTransaction::class, 'walletable');
    }

    public function withdrawalRequests()
    {
        return $this->hasMany(WithdrawalRequest::class);
    }

    public function getProfilePicUrlAttribute(): ?string
    {
        return $this->profile_pic
            ? asset("storage/{$this->profile_pic}")
            : null;
    }

    public function getCoverImageUrlAttribute(): ?string
    {
        return $this->cover_image
            ? asset("storage/{$this->cover_image}")
            : null;
    }

    public function getPlacePicsUrlsAttribute(): array
    {
        $pics = $this->place_pics ?: [];
        return array_map(fn($path) => asset("storage/{$path}"), $pics);
    }


}
