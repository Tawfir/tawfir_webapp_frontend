<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Modules\Restaurant\Entities\Restaurant;
use Modules\Restaurant\Filament\Resources\RestaurantResource;

Route::middleware(['web', 'auth'])->group(function () {
    // If they click “back” or abandon and need a fresh link
    Route::get('/restaurant/stripe/refresh', function () {
        /** @var Restaurant $r */
        $r = Auth::user()->restaurant;

        // Redirect straight into Filament’s edit page for this restaurant
        return redirect(RestaurantResource::getUrl('edit', [
            'record' => $r->id,
        ]));
    })->name('restaurant.stripe.refresh');

    // The return_url once Stripe onboarding is complete
    Route::get('/restaurant/stripe/success', function () {
        /** @var Restaurant $r */
        $r = Auth::user()->restaurant;

        //// Flag that they’ve submitted all required details
        $r->update([
            'stripe_account_details_submitted' => true,
        ]);

        // Send them back into their Filament profile editor
        return redirect('restaurant/restaurants/' . $r->id . '/edit')
            ->with('success', 'Your Stripe account is now connected! Please complete your profile details.');
    })->name('restaurant.stripe.success');
});