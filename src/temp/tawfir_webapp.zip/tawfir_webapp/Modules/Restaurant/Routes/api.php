<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\Restaurant\Http\Controllers\DishController;
use Modules\Restaurant\Http\Controllers\OrderController;
use Modules\Restaurant\Http\Controllers\RestaurantController;
use Modules\Restaurant\Http\Controllers\TransactionController;
use Modules\Restaurant\Http\Controllers\WalletController;
use Modules\Restaurant\Http\Controllers\WithdrawalController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::name('restaurant.')->prefix('restaurant')->middleware('auth:sanctum')->group(function () {

    // 1️⃣ Apply / register your restaurant
    Route::post('/',      [RestaurantController::class, 'store'])->name('store');
    Route::get('/{id?}',       [RestaurantController::class, 'show'])->name('show');

    // 2️⃣ See your own restaurant (even if pending)

    // 3️⃣ Update your restaurant details
    Route::put('/',       [RestaurantController::class, 'update'])->name('update');

    // Everything below requires the restaurant to be APPROVED
    Route::middleware('restaurant.approved')->group(function () {

        Route::prefix('wallet')->name('wallet.')->group(function () {
            // 1️⃣ Get current wallet balance
            Route::get('/', [WalletController::class, 'balance']);

            // 2️⃣ List wallet transactions
            Route::get('/transactions', [WalletController::class, 'transactions']);

            // 3️⃣ Make a withdrawal request
            Route::post('withdrawals', [WithdrawalController::class, 'store']);
        });
        // 4️⃣ Manage dishes
        Route::prefix('dishes')->name('dishes.')->group(function () {
            Route::get('/',    [DishController::class, 'index']);
            Route::post('/',   [DishController::class, 'store']);
            Route::put('{id}', [DishController::class, 'update']);
            Route::delete('{id}', [DishController::class, 'destroy']);
        });

        // 5️⃣ Manage orders
        Route::prefix('orders')->name('orders.')->group(function () {
            Route::get('/',         [OrderController::class, 'index']);
            Route::get('{id}',      [OrderController::class, 'show']);
            Route::put('{id}/status', [OrderController::class, 'updateStatus']);
        });
        Route::patch('transactions/{id}/paid', [TransactionController::class,'markPaid'])
            ->name('transactions.markPaid');
    });
});