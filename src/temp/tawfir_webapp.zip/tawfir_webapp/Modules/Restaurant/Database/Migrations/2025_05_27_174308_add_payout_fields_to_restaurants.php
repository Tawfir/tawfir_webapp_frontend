<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('restaurants', function (Blueprint $table) {
            $table->string('stripe_account_id')->nullable()->after('is_featured');
            $table->enum('payout_method', ['stripe', 'manual'])->default('manual')->after('stripe_account_id');
            $table->string('bank_name')->nullable()->after('payout_method');
            $table->string('account_holder')->nullable()->after('bank_name');
            $table->string('iban')->nullable()->after('account_holder');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('restaurants', function (Blueprint $table) {
            $table->dropColumn(['stripe_account_id','payout_method','bank_name','account_holder','iban']);
        });
    }
};
