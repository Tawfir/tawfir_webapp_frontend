<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('restaurants', function (Blueprint $table) {
            // add stripe_account_details_submitted column
            $table->boolean('stripe_account_details_submitted')
                ->default(false)
                ->after('stripe_account_id')
                ->comment('Indicates if the restaurant has submitted their Stripe account details');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('restaurants', function (Blueprint $table) {
            // drop the stripe_account_details_submitted column
            $table->dropColumn('stripe_account_details_submitted');
        });
    }
};
