<?php

namespace Modules\Auth\Http\Controllers;

use App\Enums\UserType;
use App\Models\User;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Modules\Notifications\Notifications\ResetPasswordCode;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $data = $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|email|unique:users',
            'phone'    => 'required|string|unique:users',
            'password' => 'required|string|min:6',
            //'onesignal_user_id' => 'nullable|string',
        ]);

        $user = User::create([
            'name'     => $data['name'],
            'email'    => $data['email'],
            'phone'    => $data['phone'],
            'password' => bcrypt($data['password']),
            'type'     => UserType::USER->value,
            'onesignal_user_id' => $request->onesignal_user_id ?? "",
        ]);

        $user->addRole('user');

        $token = $user->createToken('user-token')->plainTextToken;

        return $this->success(
            ['user' => $user, 'token' => $token],
            'Registration successful'
        );
    }

    public function login(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required|string',
        ]);

        $user = User::where('email',$request->email)->first();

        if(!$user){
            $this->error(
                'User not found',
                401
            );
        }

        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            $user = Auth::user();
        } else {
            throw ValidationException::withMessages([
                'credentials' => ['The provided credentials are incorrect.'],
            ]);
        }

        if($request->filled('onesignal_user_id')){
            $user->update(['onesignal_user_id'=>$request->onesignal_user_id]);
        }

        $token = $user->createToken('user-token')->plainTextToken;

        return $this->success(
            ['user' => $user, 'token' => $token],
            'Login successful'
        );
    }
    public function refresh(Request $request)
    {
        // Ensure the user is authenticated via sanctum
        $user = $request->user();

        // Revoke the token that was used to authenticate this request
        $request->user()->currentAccessToken()->delete();

        // Issue a fresh token
        $newToken = $user->createToken('user-token')->plainTextToken;

        return $this->success(
            ['token' => $newToken],
            'Token refreshed successfully'
        );
    }
    public function logout(Request $request)
    {
        $request->user()->tokens()->delete();

        return $this->success([], 'Logged out successfully');
    }

    public function user(Request $request)
    {
        return $this->success($request->user(), 'User profile retrieved successfully');
    }

    public function updateProfile(Request $request)
    {
        $user = $request->user();

        $data = $request->validate([
            'name'  => 'sometimes|string|max:255',
            'email' => 'sometimes|email|unique:users,email,' . $user->id,
            'phone' => 'sometimes|string|unique:users,phone,' . $user->id,
            'lat'   => 'sometimes|numeric|between:-90,90',
            'lng'   => 'sometimes|numeric|between:-180,180',
        ]);

        $user->fill($data)->save();   // ← mass-assign safely

        return $this->success($user, 'Profile updated successfully');
    }
    public function updatePassword(Request $request)
    {
        $user = $request->user();

        $data = $request->validate([
            'current_password' => 'required|string',
            'password'         => 'required|string|min:6|confirmed',
        ]);

        // Make sure the old password is correct
        if (! Hash::check($data['current_password'], $user->password)) {
            return $this->error('Current password is incorrect.', 422);
        }

        // Change password & revoke old tokens (recommended)
        $user->forceFill([
            'password' => bcrypt($data['password']),
        ])->save();

        // Optionally issue a fresh token so the app keeps working
        $request->user()->tokens()->delete();
        $newToken = $user->createToken('user-token')->plainTextToken;

        return $this->success(
            ['token' => $newToken],
            'Password updated successfully'
        );
    }


    public function requestPasswordResetCode(Request $request)
    {
        $request->validate(['email'=>'required|email|exists:users,email']);

        $code = random_int(100000,999999);

        DB::table('password_resets')->updateOrInsert(
            ['email'=>$request->email],
            ['token'=>$code,'created_at'=>now()]
        );

        $user = User::where('email',$request->email)->first();
        $user->notify(new ResetPasswordCode($code));

        return $this->success([], 'Reset code sent');
    }
    /**
     * Verify a password reset code without changing password.
     */
    public function checkResetCode(Request $request)
    {
        // 1) validate input
        $data = $request->validate([
            'email' => 'required|email|exists:users,email',
            'code'  => 'required|digits:6',
        ]);

        // 2) lookup the stored code
        $row = DB::table('password_resets')
            ->where('email', $data['email'])
            ->where('token', $data['code'])
            ->first();

        // 3) check existence & expiry
        $expires = config('auth.passwords.users.expire');
        if (! $row || Carbon::parse($row->created_at)->addMinutes($expires)->isPast()) {
            return $this->error('Invalid or expired code', 422);
        }

        // 4) success (no sensitive data returned)
        return $this->success([], 'Code is valid');
    }

    public function resetPasswordWithCode(Request $request)
    {
        $data = $request->validate([
            'email'    =>'required|email|exists:users,email',
            'code'     =>'required|digits:6',
            'password' =>'required|string|min:6|confirmed',
        ]);

        $row = DB::table('password_resets')
            ->where('email',$data['email'])
            ->where('token',$data['code'])
            ->first();

        $expires = config('auth.passwords.users.expire');
        if(!$row || Carbon::parse($row->created_at)->addMinutes($expires)->isPast()){
            return $this->error('Invalid or expired code', 422);
        }

        $user = User::where('email',$data['email'])->first();
        $user->password = bcrypt($data['password']);
        $user->save();

        DB::table('password_resets')->where('email',$data['email'])->delete();

        return $this->success([], 'Password reset successfully');
    }

    public function deleteAccount(Request $request)
    {
        /** @var \App\Models\User $user */
        $user = $request->user();
        // must be a normal user, not admin
        if ($user->type !== UserType::USER->value) {
            return $this->error('You are not allowed to delete this account.', 403);
        }

        // revoke all tokens before deletion (optional but recommended)
        $user->tokens()->delete();

        // this will soft-delete user + cascade to orders
        $user->delete();

        return $this->success(null, 'Your account and its orders have been deleted.');
    }
}
