<?php

use Illuminate\Http\Request;
use Modules\Auth\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('auth')->group(function () {
    Route::post('register',                   [AuthController::class, 'register']);
    Route::post('login',                      [AuthController::class, 'login']);
    Route::post('request-password-reset-code',[AuthController::class, 'requestPasswordResetCode']);
    Route::post('check-reset-code', [AuthController::class, 'checkResetCode']);
    Route::post('reset-password-with-code',   [AuthController::class, 'resetPasswordWithCode']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('refresh', [AuthController::class, 'refresh']);
        Route::post('logout',                 [AuthController::class, 'logout']);
        Route::delete('user',                      [AuthController::class, 'deleteAccount']);
        Route::get('user',                      [AuthController::class, 'user']);
        Route::put('update-profile',          [AuthController::class, 'updateProfile']);
        Route::post('password/update',          [AuthController::class, 'updatePassword']);

    });
});