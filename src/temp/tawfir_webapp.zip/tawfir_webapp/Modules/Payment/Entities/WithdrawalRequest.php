<?php

namespace Modules\Payment\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Restaurant\Entities\Restaurant;

class WithdrawalRequest extends Model
{
    protected $fillable = ['restaurant_id','amount','method','status','stripe_payout_id','admin_notes'];

    public function restaurant()
    {
        return $this->belongsTo(Restaurant::class);
    }
}
