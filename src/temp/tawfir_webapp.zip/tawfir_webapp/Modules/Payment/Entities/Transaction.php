<?php

namespace Modules\Payment\Entities;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\User\Entities\Order;

class Transaction extends Model
{
    protected $fillable = [
        'order_id','user_id','amount_cents','currency',
        'type','method','status','gateway_id','response_raw','metadata'
    ];

    protected $casts = [
        'response_raw' => 'array',
        'metadata'     => 'array',
    ];

    public function order() { return $this->belongsTo(Order::class); }
    public function user()  { return $this->belongsTo(User::class); }
}
