<?php

namespace Modules\Payment\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class StripeWebhookController extends Controller
{
    public function handle(Request $request)
    {
        $driver = app(\Modules\Payment\Services\StripePaymentDriver::class);
        $driver->handleWebhook($request);
        return response()->noContent();
    }
}
