<?php

namespace Modules\Payment\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Modules\Payment\Entities\Transaction;
use Modules\User\Entities\Order;
use Modules\User\Entities\OrderItem;

class CheckoutController extends Controller
{
    public function checkout(Request $request)
    {
        $request->validate([
            'payment_method' => 'required|in:' . implode(',', array_keys(config('payment_methods'))),
        ]);

        $user = $request->user();

        DB::beginTransaction();
        try {
            // 1️⃣ Build orders
            $cart = $user->cartItems()->with('dish')->get();
            if ($cart->isEmpty()) {
                throw new \Exception(__('Cart is empty'));
            }

            $orders = [];
            foreach ($cart->groupBy(fn ($i) => $i->dish->restaurant_id) as $rid => $items) {
                $order = Order::create([
                    'user_id'       => $user->id,
                    'restaurant_id' => $rid,
                    'total_price'   => 0,
                    'pickup_time'   => $items->first()->dish->pickup_time ?? now()->addHour(),
                    'status'        => \Modules\User\Enums\OrderStatus::INCOMING->value,
                ]);

                $total = 0;
                foreach ($items as $item) {
                    $dish  = $item->dish;
                    $price = $dish->discounted_price ?? $dish->price;

                    if ($dish->quantity < $item->quantity) {
                        throw new \Exception(__('Not enough quantity for :dish', ['dish' => $dish->name]));
                    }

                    OrderItem::create([
                        'order_id'            => $order->id,
                        'dish_id'             => $dish->id,
                        'quantity'            => $item->quantity,
                        'price_at_order_time' => $price,
                    ]);

                    $dish->decrement('quantity', $item->quantity);
                    $total += $price * $item->quantity;
                }

                $order->update(['total_price' => $total]);
                $orders[] = $order;
            }

            // Clear cart only for cash payments (not for Stripe)
            $paymentMethod = $request->input('payment_method');
            if ($paymentMethod === 'cash') {
                $user->cartItems()->delete();
            }

            // 2️⃣ Create one transaction per order + intent
            $paymentMethod = $request->input('payment_method');
            $driverClass   = config("payment_methods.{$paymentMethod}");
            $driver        = app($driverClass);

            $payments = [];
            foreach ($orders as $order) {
                $amountCents = $order->total_price * 100;
                $currency    = $order->currency ?? 'usd';

                $txn = Transaction::create([
                    'order_id'     => $order->id,
                    'user_id'      => $user->id,
                    'amount_cents' => $amountCents,
                    'currency'     => $currency,
                    'type'         => 'payment',
                    'method'       => $paymentMethod,
                    'status'       => 'pending',
                ]);

                // if driver throws, we'll catch it below and rollback everything
                $intent = $driver->createIntent($amountCents, $currency, [
                    'order_id'       => $order->id,
                    'transaction_id' => $txn->id,
                ]);

                $txn->update([
                    'gateway_id'   => $intent['payment_intent_id'] ?? null,
                    'response_raw' => $intent,
                ]);

                $payments[] = [
                    'order_id'      => $order->id,
                    'transaction_id' => $txn->id,
                    'client_secret' => $intent['client_secret'] ?? null,
                ];
            }

            DB::commit();
            $orders = Order::with(['restaurant', 'items.dish'])->whereIn('id', collect($orders)->pluck('id'))->get();

            // 3️⃣ Everything succeeded
            return $this->success([
                'payments'       => $payments,
                'payment_method' => $paymentMethod,
                'orders'          => $orders,
            ], __('Proceed to payment'));

        } catch (\Throwable $e) {
            DB::rollBack();

            // You can inspect $e for more details or custom exception types
            return $this->error(__('Checkout failed: :message', ['message' => $e->getMessage()]), 422);
        }
    }
}
