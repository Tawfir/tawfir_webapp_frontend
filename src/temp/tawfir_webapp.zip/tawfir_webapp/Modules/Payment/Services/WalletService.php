<?php

namespace Modules\Payment\Services;

use Illuminate\Support\Facades\DB;

class WalletService
{
    public static function credit($entity, float $amount, string $description = null, $orderId = null)
    {
        return self::record($entity, 'credit', $amount, $description, $orderId);
    }

    public static function debit($entity, float $amount, string $description = null, $orderId = null)
    {
        return self::record($entity, 'debit', $amount, $description, $orderId);
    }

    protected static function record($entity, string $type, float $amount, string $description = null, $orderId = null)
    {
        return DB::transaction(function () use ($entity, $type, $amount, $description, $orderId) {
            return $entity->walletTransactions()->create([
                'type' => $type,
                'amount' => $amount,
                'description' => $description,
                'order_id' => $orderId,
            ]);
        });
    }

    public static function balance($entity)
    {
        $credit = $entity->walletTransactions()->where('type','credit')->sum('amount');
        $debit  = $entity->walletTransactions()->where('type','debit')->sum('amount');
        return $credit - $debit;
    }
}