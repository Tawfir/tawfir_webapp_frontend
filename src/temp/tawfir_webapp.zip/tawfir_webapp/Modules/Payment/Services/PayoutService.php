<?php

namespace Modules\Payment\Services;

use Modules\Payment\Entities\WithdrawalRequest;
use Stripe\Stripe;
use Stripe\Transfer;

class PayoutService
{
    public function __construct()
    {
        Stripe::setApiKey(env('STRIPE_SECRET'));
    }

    public function process(WithdrawalRequest $wr): void
    {
        if ($wr->method === 'stripe') {
            // Create a Stripe Transfer from your platform to the connected account
            $transfer = Transfer::create([
                'amount'      => (int) round($wr->amount * 100),
                'currency'    => 'usd', // or your currency
                'destination' => $wr->restaurant->stripe_account_id,
                'description' => "Withdrawal #{$wr->id}",
            ]);

            // Mark the withdrawal paid and record the Stripe transfer ID
            $wr->update([
                'stripe_payout_id' => $transfer->id,
                'status'           => 'paid',
                'processed_at'     => now(),
            ]);

            // Finally, debit the restaurant wallet
            WalletService::debit(
                $wr->restaurant,
                $wr->amount,
                "Withdrawal #{$wr->id}",
                null
            );

            return;
        }

        // Fallback to manual
        $wr->update(['status' => 'paid','processed_at'=>now()]);
        WalletService::debit($wr->restaurant, $wr->amount, "Withdrawal #{$wr->id}", null);
    }
}