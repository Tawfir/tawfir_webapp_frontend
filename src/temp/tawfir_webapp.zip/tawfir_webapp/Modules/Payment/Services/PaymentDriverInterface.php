<?php
namespace Modules\Payment\Services;

use Illuminate\Http\Request;

interface PaymentDriverInterface
{
    public function createIntent(int $amountCents, string $currency, array $metadata): array;
    public function handleWebhook(Request $request): void;
}
