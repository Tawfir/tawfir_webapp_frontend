<?php

namespace Modules\Payment\Services;
use Illuminate\Http\Request;
use Modules\Payment\Services\PaymentDriverInterface;


class CashPaymentDriver implements PaymentDriverInterface {
    public function createIntent($amountCents, $currency, $metadata): array
    {
        // For cash we don’t contact any API:
        return [
            'payment_intent_id' => null,
            'client_secret'     => null,
        ];
    }
    public function handleWebhook(Request $request): void
    {
        // no‐op for cash
    }
}