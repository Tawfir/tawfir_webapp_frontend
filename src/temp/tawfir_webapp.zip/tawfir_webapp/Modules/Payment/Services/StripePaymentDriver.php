<?php

namespace Modules\Payment\Services;

use Modules\Payment\Entities\Transaction;
use Modules\Payment\Services\PaymentDriverInterface;
use Illuminate\Http\Request;
use Stripe\PaymentIntent;
use Stripe\Stripe;
use Stripe\Webhook;

class StripePaymentDriver implements PaymentDriverInterface
{
    public function createIntent($amountCents, $currency, $metadata): array
    {
        Stripe::setApiKey(env('STRIPE_SECRET'));

        // static call now works because you imported PaymentIntent
        $pi = PaymentIntent::create([
            'amount'   => $amountCents,
            'currency' => $currency ?? 'usd',
            'metadata' => $metadata,
            'payment_method_types'  => ['card'],
        ]);

        return [
            'payment_intent_id' => $pi->id,
            'client_secret'     => $pi->client_secret,
        ];
    }

    public function handleWebhook(Request $request): void
    {
        Stripe::setApiKey(env('STRIPE_SECRET'));

        $event = Webhook::constructEvent(
            $request->getContent(),
            $request->header('Stripe-Signature'),
            env('STRIPE_WEBHOOK_SECRET')
        );

        $pi = $event->data->object;

        switch ($event->type) {
            case 'payment_intent.succeeded':
                // 1️⃣ Update your Transaction record
                $txn = Transaction::where('gateway_id', $pi->id)->first();
                $txn->update([
                    'status' => 'succeeded',
                    'response_raw' => $pi,
                ]);

                // 2️⃣ Grab the order & compute net
                $order = $txn->order;
                $total = $order->total_price;
                $feePct = config('payment.service_fee_percent');
                $serviceFee = ($total * $feePct) / 100;
                $netToRestaurant = $total - $serviceFee;

                // 3️⃣ Credit the restaurant’s wallet
                WalletService::credit(
                    $order->restaurant,
                    $netToRestaurant,
                    "Order #{$order->id}",
                    $order->id
                );

                // 4️⃣ Clear user's cart for this order's dishes
                $orderItems = $order->items()->pluck('dish_id');
                $order->user->cartItems()->whereIn('dish_id', $orderItems)->delete();

                // 5️⃣ Optionally mark the order confirmed
                //$order->update(['status' => 'confirmed']);
                break;

            case 'charge.refunded':
                // If you listen to refund events, reverse the wallet credit
                $charge = $event->data->object;
                $txn = Transaction::where('gateway_id', $charge->payment_intent)->first();
                $order = $txn->order;
                $total = $order->total_price;
                $serviceFee = ($total * config('payment.service_fee_percent')) / 100;
                $net = $total - $serviceFee;

                WalletService::debit(
                    $order->restaurant,
                    $net,
                    "Refund Order #{$order->id}",
                    $order->id
                );
                break;

            case 'payment_intent.payment_failed':
                // update transaction/order if you need…
                Transaction::where('gateway_id', $pi->id)
                    ->update(['status' => 'failed', 'response_raw' => $pi]);
                break;
        }
    }
}
