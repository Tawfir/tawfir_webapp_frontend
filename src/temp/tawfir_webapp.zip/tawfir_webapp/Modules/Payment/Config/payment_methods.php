<?php

return [
    'stripe' => \Modules\Payment\Services\StripePaymentDriver::class,
    'cash'   => \Modules\Payment\Services\CashPaymentDriver::class,
    // future: 'paypal' => \Modules\Payment\Services\PaypalDriver::class,
    'service_fee_percent' => 7.5,
];
