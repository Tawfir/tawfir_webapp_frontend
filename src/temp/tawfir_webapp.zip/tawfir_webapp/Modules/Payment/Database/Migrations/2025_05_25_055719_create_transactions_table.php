<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up(): void
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->bigIncrements('id');

            // link back to the order, if any (nullable for wallet top-ups, refunds, etc.)
            $table->foreignId('order_id')
                ->nullable()
                ->constrained()
                ->cascadeOnDelete();

            // the user who paid or received funds
            $table->foreignId('user_id')
                ->constrained()
                ->cascadeOnDelete();

            // amount in cents
            $table->unsignedBigInteger('amount_cents');

            // ISO currency code, e.g. "usd"
            $table->string('currency', 3)->default('usd');

            // what kind of transaction: payment, wallet_deposit, refund, etc.
            $table->string('type')->index();

            // which method/gateway: stripe, cash, wallet, paypal…
            $table->string('method')->index();

            // pending, succeeded, failed, cancelled…
            $table->string('status')->index();

            // e.g. Stripe PaymentIntent ID, nullable for cash/wallet
            $table->string('gateway_id')->nullable()->unique();

            // raw gateway response for debugging/audit
            $table->json('response_raw')->nullable();

            // any extra metadata (e.g. {"order_note":"gift"} )
            $table->json('metadata')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
};
