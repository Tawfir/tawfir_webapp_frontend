<?php

use Illuminate\Http\Request;
use Modules\Payment\Http\Controllers\CheckoutController;
use Modules\Payment\Http\Controllers\StripeWebhookController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->prefix('payment')->group(function () {
    Route::post('checkout', [CheckoutController::class,'checkout'])->name('payment.checkout');
});

// and keep your webhook public
Route::post('stripe/webhook', [StripeWebhookController::class,'handle']);
