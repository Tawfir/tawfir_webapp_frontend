<x-filament-widgets::widget>
    <x-filament::section>
        <div class="flex items-center gap-4">
            <div class="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-xl font-semibold">
                {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
            </div>
            <div>
                <p class="text-sm text-gray-500 dark:text-gray-400">Welcome back</p>
                <p class="text-lg font-semibold">{{ auth()->user()->name }}</p>
            </div>
        </div>
    </x-filament::section>
</x-filament-widgets::widget>

