<?php

namespace Modules\Admin\Filament\Resources;

use Filament\Notifications\Notification;
use Modules\Admin\Filament\Resources\RestaurantResource\Pages\CreateRestaurant;
use Modules\Admin\Filament\Resources\RestaurantResource\Pages\EditRestaurant;
use Modules\Admin\Filament\Resources\RestaurantResource\Pages\ListRestaurants;
use Modules\Admin\Filament\Resources\RestaurantResource\Pages\ViewRestaurant;
use Modules\Restaurant\Entities\Restaurant;
use Filament\Resources\Resource;

use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\TimePicker;
use Filament\Forms\Components\MultiSelect;
use Filament\Forms\Components\FileUpload;

use Filament\Tables;
use Filament\Tables\Columns\BadgeColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\BulkAction;
use Filament\Tables\Actions\DeleteBulkAction;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Modules\Restaurant\Enums\RestaurantStatus;

class RestaurantResource extends Resource
{
    protected static ?string $model = Restaurant::class;

    protected static ?string $navigationIcon      = 'heroicon-o-building-office';
    protected static ?string $navigationGroup     = 'Restaurant Management';
    protected static ?string $modelLabel          = 'Restaurant';
    protected static ?string $pluralModelLabel    = 'Restaurants';
    public    static ?string $recordTitleAttribute = 'name';

    public static function form(\Filament\Forms\Form $form): \Filament\Forms\Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->label('Name')
                    ->required()
                    ->maxLength(255),

                TextInput::make('address')
                    ->label('Address')
                    ->required()
                    ->maxLength(500),

                TextInput::make('lat')
                    ->label('Latitude')
                    ->numeric()
                    ->required(),

                TextInput::make('lng')
                    ->label('Longitude')
                    ->numeric()
                    ->required(),

                Repeater::make('working_hours')
                    ->label('Working Hours')
                    ->columns(3)
                    ->schema([
                        Select::make('day')
                            ->label('Day')
                            ->options([
                                'monday'    => 'Monday',
                                'tuesday'   => 'Tuesday',
                                'wednesday' => 'Wednesday',
                                'thursday'  => 'Thursday',
                                'friday'    => 'Friday',
                                'saturday'  => 'Saturday',
                                'sunday'    => 'Sunday',
                            ])
                            ->required(),
                        TimePicker::make('open')
                            ->label('Open')
                            ->withoutSeconds()
                            ->required(),
                        TimePicker::make('close')
                            ->label('Close')
                            ->withoutSeconds()
                            ->required(),
                    ])
                    ->minItems(7)
                    ->defaultItems(7)
                    ->columnSpan('full'),

                TextInput::make('public_phone')
                    ->label('Public Phone')
                    ->tel()
                    ->required(),

                TextInput::make('private_phone')
                    ->label('Private Phone')
                    ->tel()
                    ->required(),

                Select::make('food_category_ids')
                    ->label('Food Categories')
                    ->relationship('categories','name')
                    ->multiple()
                    ->preload()
                    ->required(),

                FileUpload::make('place_pics')
                    ->label('Place Pictures')
                    ->image()
                    ->multiple()
                    ->maxFiles(5)
                    ->directory('restaurants/place-pics'),

                FileUpload::make('profile_pic')
                    ->label('Profile Picture')
                    ->image()
                    ->directory('restaurants/profile-pics'),

                FileUpload::make('cover_image')
                    ->label('Cover Image')
                    ->image()
                    ->directory('restaurants/cover-images'),

                Select::make('status')
                    ->label('Approval Status')
                    ->options([
                        'pending'  => 'Pending',
                        'approved' => 'Approved',
                        'rejected' => 'Rejected',
                    ])
                    ->required(),

                Toggle::make('is_featured')
                    ->label('Featured')
                    ->helperText('Highlight this restaurant on the home page'),
            ]);
    }

    public static function table(Tables\Table $table): Tables\Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('ID')
                    ->sortable(),

                TextColumn::make('name')
                    ->label('Name')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('user.name')
                    ->label('Owner')
                    ->sortable(),

                TextColumn::make('address')
                    ->label('Address')
                    ->limit(30),

                TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    // Accept any $state and pull out the enum’s value
                    ->formatStateUsing(fn ($state): string => match (true) {
                        $state instanceof RestaurantStatus =>
                        match ($state) {
                            RestaurantStatus::PENDING  => 'pending',
                            RestaurantStatus::APPROVED => 'approved',
                            RestaurantStatus::REJECTED => 'rejected',
                        },
                        default => ucfirst((string) $state),
                    })
                    ->colors([
                        'warning' => fn ($state): bool => ($state instanceof RestaurantStatus ? $state : RestaurantStatus::from($state)) === RestaurantStatus::PENDING,
                        'success' => fn ($state): bool => ($state instanceof RestaurantStatus ? $state : RestaurantStatus::from($state)) === RestaurantStatus::APPROVED,
                        'danger'  => fn ($state): bool => ($state instanceof RestaurantStatus ? $state : RestaurantStatus::from($state)) === RestaurantStatus::REJECTED,
                    ]),

                // featured flag as a badge
                TextColumn::make('is_featured')
                    ->label('Featured')
                    ->badge()
                    ->formatStateUsing(fn (bool $state): string => $state ? 'Yes' : 'No')
                    ->colors([
                        'primary'   => fn ($state): bool => $state === true,
                        'secondary' => fn ($state): bool => $state === false,
                    ]),

                TextColumn::make('created_at')
                    ->label('Created')
                    ->dateTime('d/m/Y'),
            ])
            ->filters([
                SelectFilter::make('status')
                    ->label('Status')
                    ->options([
                        'pending'  => 'Pending',
                        'approved' => 'Approved',
                        'rejected' => 'Rejected',
                    ]),
                SelectFilter::make('is_featured')
                    ->label('Featured')
                    ->options([
                        1 => 'Featured',
                        0 => 'Not Featured',
                    ]),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),

                    BulkAction::make('approve')
                        ->label('Approve')
                        ->action(function ($records) {
                            $records->each(fn ($r) => $r->update(['status' => 'approved']));
                            Notification::make()
                                ->success()
                                ->title('Restaurants Approved')
                                ->body('Selected restaurants have been approved.')
                                ->send();
                        }),

                    BulkAction::make('feature')
                        ->label('Feature')
                        ->action(function ($records) {
                            $records->each(fn ($r) => $r->update(['is_featured' => true]));
                            Notification::make()
                                ->success()
                                ->title('Restaurants Featured')
                                ->body('Selected restaurants have been marked as featured.')
                                ->send();
                        }),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            // e.g. RelationManagers\OrdersRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index'  => ListRestaurants::route('/'),
            'create' => CreateRestaurant::route('/create'),
            'view'   => ViewRestaurant::route('/{record}'),
            'edit'   => EditRestaurant::route('/{record}/edit'),
        ];
    }
}
