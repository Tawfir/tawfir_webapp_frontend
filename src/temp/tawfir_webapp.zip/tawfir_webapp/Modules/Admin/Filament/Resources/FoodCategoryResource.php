<?php

namespace Modules\Admin\Filament\Resources;

use App\Services\ImageUploadService;
use Closure;
use Filament\Forms\Get;
use Filament\Forms\Set;
use Filament\Resources\Resource;
use Filament\Resources\Pages;
use Filament\Forms;
use Filament\Tables;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\FileUpload;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Modules\Restaurant\Entities\FoodCategory;
use Modules\Admin\Filament\Resources\FoodCategoryResource\Pages\ListFoodCategories;
use Modules\Admin\Filament\Resources\FoodCategoryResource\Pages\CreateFoodCategory;
use Modules\Admin\Filament\Resources\FoodCategoryResource\Pages\EditFoodCategory;


class FoodCategoryResource extends Resource
{
    protected static ?string $model = FoodCategory::class;
    protected static ?string $navigationIcon = 'heroicon-o-tag';
    protected static ?string $navigationGroup = 'Restaurant Management';
    protected static ?int $navigationSort = 2;

    public static function form(Forms\Form $form): Forms\Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->label('Name')
                    ->required()
                    ->maxLength(255)
                    ->lazy(),  // only sync on blur or final submit

                //TextInput::make('slug')
                //    ->label('Slug')
                //    ->required()
                //    ->maxLength(255)
                //    ->lazy()   // ditto
                //    ->afterStateUpdated(fn (Set $set, ?string $state) => $set('slug', Str::slug($state))),

                FileUpload::make('cover')
                    ->label('Cover Image')
                    ->image()
                    ->maxSize(1024)
                    ->disk('public')
                    ->directory('food-categories/covers')      // ← HERE
                    ->saveUploadedFileUsing(fn($file): string =>
                    app(ImageUploadService::class)
                        ->upload($file, 'food-category-cover')['path']
                    )
                    ->deleteUploadedFileUsing(fn(string $path): bool =>
                    Storage::disk('public')->delete($path)
                    ),

                FileUpload::make('image')
                    ->label('Category Image')
                    ->image()
                    ->maxSize(1024)
                    ->disk('public')
                    ->directory('food-categories/images')      // ← AND HERE
                    ->saveUploadedFileUsing(fn($file): string =>
                    app(ImageUploadService::class)
                        ->upload($file, 'food-category-image')['path']
                    )
                    ->deleteUploadedFileUsing(fn(string $path): bool =>
                    Storage::disk('public')->delete($path)
                    ),

            ]);
    }

    public static function table(Tables\Table $table): Tables\Table
    {
        return $table
            ->columns([
                ImageColumn::make('cover')->label('Cover')->rounded(),
                TextColumn::make('name')->searchable()->sortable(),
                TextColumn::make('slug')->sortable(),
                TextColumn::make('dishes_count')
                    ->label('Dishes')
                    ->counts('dishes'),
                TextColumn::make('restaurants_count')
                    ->label('Restaurants')
                    ->counts('restaurants'),
                Tables\Columns\IconColumn::make('deleted_at')
                    ->boolean()
                    ->label('Trashed'),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
                Tables\Actions\ForceDeleteAction::make(),
                Tables\Actions\RestoreAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
                Tables\Actions\RestoreBulkAction::make(),
                Tables\Actions\ForceDeleteBulkAction::make(),
            ]);
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListFoodCategories::route('/'),
            'create' => CreateFoodCategory::route('/create'),
            'edit' => EditFoodCategory::route('/{record}/edit'),
        ];
    }
}
