<?php

namespace Modules\Admin\Filament\Resources\WithdrawalRequestResource\Pages;

use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
use Modules\Admin\Filament\Resources\RestaurantResource;
use Modules\Admin\Filament\Resources\WithdrawalRequestResource;

class ListWithdrawalRequests extends ListRecords
{
    protected static string $resource = WithdrawalRequestResource::class;
}
