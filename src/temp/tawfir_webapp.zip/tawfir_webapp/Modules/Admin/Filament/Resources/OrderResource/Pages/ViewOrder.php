<?php

namespace Modules\Admin\Filament\Resources\OrderResource\Pages;

use Filament\Resources\Pages\ViewRecord;
use Filament\Infolists\Infolist;
use Filament\Infolists\Components\Section;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Components\RepeatableEntry;
use Modules\Admin\Filament\Resources\OrderResource;

class ViewOrder extends ViewRecord
{
    protected static string $resource = OrderResource::class;

    public function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->record($this->record)            // << you must set the record
            ->schema([
                Section::make('Order Summary')->columns(2)->schema([
                    TextEntry::make('id')->label('Order ID'),
                    TextEntry::make('user.name')->label('Customer'),
                    TextEntry::make('restaurant.name')->label('Restaurant'),
                    TextEntry::make('total_price')->label('Total Price')->money('USD'),
                    TextEntry::make('pickup_time')->label('Pickup Time')->dateTime('H:i'),
                    TextEntry::make('status')->label('Status'),
                ]),

                Section::make('Order Items')->schema([
                    RepeatableEntry::make('items') // match the relation name
                    ->label('Dishes')
                        ->schema([
                            TextEntry::make('dish.name')->label('Dish'),
                            TextEntry::make('quantity')->label('Qty'),
                            TextEntry::make('price_at_order_time')->label('Price')->money('USD'),
                        ]),
                ]),
            ]);
    }
}
