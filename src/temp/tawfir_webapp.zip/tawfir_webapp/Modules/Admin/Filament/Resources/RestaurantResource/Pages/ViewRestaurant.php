<?php

namespace Modules\Admin\Filament\Resources\RestaurantResource\Pages;

use Modules\Admin\Filament\Resources\RestaurantResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;
use Filament\Infolists;
use Filament\Infolists\Infolist;
use Modules\Restaurant\Enums\RestaurantStatus;

class ViewRestaurant extends ViewRecord
{
    protected static string $resource = RestaurantResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\EditAction::make(),
        ];
    }

    public function getBreadcrumbs(): array
    {
        $resource = static::$resource;
        $name = $this->getRecordTitle();

        return [
            $resource::getUrl() => $resource::getBreadcrumb(),
            $this->getBreadcrumb(),
        ];
    }

    public function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->record($this->record)
            ->schema([
                Infolists\Components\Section::make('Restaurant Information')
                    ->schema([
                        Infolists\Components\TextEntry::make('name')
                            ->label('Name'),
                        Infolists\Components\TextEntry::make('address')
                            ->label('Address'),
                        Infolists\Components\TextEntry::make('user.name')
                            ->label('Owner'),
                        Infolists\Components\TextEntry::make('public_phone')
                            ->label('Public Phone'),
                        Infolists\Components\TextEntry::make('private_phone')
                            ->label('Private Phone'),
                        Infolists\Components\TextEntry::make('status')
                            ->label('Status')
                            ->badge()
                            ->formatStateUsing(fn ($state): string => match (true) {
                                $state instanceof RestaurantStatus =>
                                    match ($state) {
                                        RestaurantStatus::PENDING => 'Pending',
                                        RestaurantStatus::APPROVED => 'Approved',
                                        RestaurantStatus::REJECTED => 'Rejected',
                                    },
                                default => ucfirst((string) $state),
                            })
                            ->colors([
                                'warning' => fn ($state): bool => ($state instanceof RestaurantStatus ? $state : RestaurantStatus::from($state)) === RestaurantStatus::PENDING,
                                'success' => fn ($state): bool => ($state instanceof RestaurantStatus ? $state : RestaurantStatus::from($state)) === RestaurantStatus::APPROVED,
                                'danger' => fn ($state): bool => ($state instanceof RestaurantStatus ? $state : RestaurantStatus::from($state)) === RestaurantStatus::REJECTED,
                            ]),
                        Infolists\Components\IconEntry::make('is_featured')
                            ->label('Featured')
                            ->boolean(),
                    ])
                    ->columns(2),
                
                Infolists\Components\Section::make('Location')
                    ->schema([
                        Infolists\Components\TextEntry::make('lat')
                            ->label('Latitude'),
                        Infolists\Components\TextEntry::make('lng')
                            ->label('Longitude'),
                    ])
                    ->columns(2),
                
                Infolists\Components\Section::make('Images')
                    ->schema([
                        Infolists\Components\ImageEntry::make('profile_pic')
                            ->label('Profile Picture')
                            ->circular()
                            ->width('150px'),
                        Infolists\Components\ImageEntry::make('cover_image')
                            ->label('Cover Image')
                            ->width('full'),
                        Infolists\Components\ImageEntry::make('place_pics')
                            ->label('Place Pictures')
                            ->limit(5),
                    ]),
                
                Infolists\Components\Section::make('Working Hours')
                    ->schema([
                        Infolists\Components\RepeatableEntry::make('working_hours')
                            ->schema([
                                Infolists\Components\TextEntry::make('day')
                                    ->label('Day')
                                    ->formatStateUsing(fn($state) => ucfirst($state)),
                                Infolists\Components\TextEntry::make('open')
                                    ->label('Opens')
                                    ->time('H:i'),
                                Infolists\Components\TextEntry::make('close')
                                    ->label('Closes')
                                    ->time('H:i'),
                            ])
                            ->columns(3),
                    ]),
                
                Infolists\Components\Section::make('Categories')
                    ->schema([
                        Infolists\Components\TextEntry::make('categories.name')
                            ->label('Food Categories')
                            ->badge()
                            ->separator(',')
                            ->placeholder('No categories'),
                    ]),
            ]);
    }
}

