<?php

namespace Modules\Admin\Filament\Resources\FoodCategoryResource\Pages;
use Filament\Resources\Pages\CreateRecord;
use Modules\Admin\Filament\Resources\FoodCategoryResource;
use Modules\Admin\Filament\Resources\OrderResource;

class CreateFoodCategory extends CreateRecord
{
    protected static string $resource = FoodCategoryResource::class;

}