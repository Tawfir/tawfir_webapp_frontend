<?php

namespace Modules\Admin\Filament\Resources\FoodCategoryResource\Pages;

use Modules\Admin\Filament\Resources\FoodCategoryResource;
use Filament\Resources\Pages\EditRecord;

class EditFoodCategory extends EditRecord
{
    protected static string $resource = FoodCategoryResource::class;

}