<?php

namespace Modules\Admin\Filament\Resources;

use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Forms\Form;
use Filament\Forms;
use Modules\Admin\Filament\Resources\OrderResource\Pages\ListOrders;
use Modules\Admin\Filament\Resources\OrderResource\Pages\ViewOrder;
use Modules\User\Entities\Order;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\BadgeColumn;
use Modules\Admin\Filament\Resources\OrderResource\Pages;
use Illuminate\Database\Eloquent\Builder;

class OrderResource extends Resource
{
    protected static ?string $model = Order::class;
    public static ?string $panel = 'admin';
    protected static ?string $navigationLabel = 'Order History';
    protected static ?string $navigationIcon = 'heroicon-o-receipt-percent';
    protected static ?string $navigationGroup = 'Orders';

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('Order #')
                    ->sortable(),
                TextColumn::make('user.name')
                    ->label('Customer')
                    ->searchable(),
                TextColumn::make('restaurant.name')
                    ->label('Restaurant')
                    ->searchable(),
                TextColumn::make('total_price')
                    ->money('USD')
                    ->sortable(),
                BadgeColumn::make('status')
                    ->colors([
                        'incoming' => 'info',
                        'ready' => 'warning',
                        'completed' => 'success',
                    ])
                    ->label('Status')
                    ->sortable(),
                TextColumn::make('created_at')
                    ->dateTime('d/m/Y H:i')
                    ->label('Date')
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\Filter::make('order_id')
                    ->form([
                        Forms\Components\TextInput::make('order_id')
                            ->label('Order #')
                            ->placeholder('Enter order number')
                            ->numeric(),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['order_id'],
                                fn (Builder $query, $orderId): Builder => $query->where('id', $orderId),
                            );
                    }),
                Tables\Filters\SelectFilter::make('status')
                    ->options([
                        'incoming' => 'Incoming',
                        'ready' => 'Ready',
                        'completed' => 'Completed',
                    ]),
                Tables\Filters\Filter::make('created_at')
                    ->form([
                        Forms\Components\DatePicker::make('created_from')
                            ->label('From Date'),
                        Forms\Components\DatePicker::make('created_until')
                            ->label('Until Date'),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['created_from'],
                                fn (Builder $query, $date): Builder => $query->whereDate('created_at', '>=', $date),
                            )
                            ->when(
                                $data['created_until'],
                                fn (Builder $query, $date): Builder => $query->whereDate('created_at', '<=', $date),
                            );
                    }),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
            ])
            ->defaultSort('created_at', 'desc');
    }

    public static function form(Form $form): Form
    {
        return $form->schema([]); // not editable
    }

    public static function getPages(): array
    {
        return [
            'index' => ListOrders::route('/'),
            'view'  => ViewOrder::route('/{record}'),
        ];
    }
}
