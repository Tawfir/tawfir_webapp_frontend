<?php

namespace Modules\Admin\Filament\Resources\RestaurantResource\Pages;

use Modules\Admin\Filament\Resources\RestaurantResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditRestaurant extends EditRecord
{
    protected static string $resource = RestaurantResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }

    public function getBreadcrumbs(): array
    {
        $resource = static::$resource;
        $name = $this->getRecordTitle();

        return [
            $resource::getUrl() => $resource::getBreadcrumb(),
            $this->getResource()::getUrl('view', ['record' => $this->getRecord()]) => $name,
            $this->getBreadcrumb(),
        ];
    }
}
