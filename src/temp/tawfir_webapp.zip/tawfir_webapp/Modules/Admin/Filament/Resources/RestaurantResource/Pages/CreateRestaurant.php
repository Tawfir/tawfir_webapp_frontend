<?php

namespace Modules\Admin\Filament\Resources\RestaurantResource\Pages;

use Modules\Admin\Filament\Resources\RestaurantResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRestaurant extends CreateRecord
{
    protected static string $resource = RestaurantResource::class;
}
