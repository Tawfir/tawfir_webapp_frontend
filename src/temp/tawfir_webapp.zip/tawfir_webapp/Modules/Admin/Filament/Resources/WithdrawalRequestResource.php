<?php

namespace Modules\Admin\Filament\Resources;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Forms\Form;
use Modules\Admin\Filament\Resources\OrderResource\Pages\ListOrders;
use Modules\Admin\Filament\Resources\OrderResource\Pages\ViewOrder;
use Modules\Admin\Filament\Resources\WithdrawalRequestResource\Pages\ListWithdrawalRequests;
use Modules\Payment\Entities\WithdrawalRequest;
use Modules\Payment\Services\PayoutService;
use Modules\User\Entities\Order;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\BadgeColumn;
use Modules\Admin\Filament\Resources\OrderResource\Pages;

class WithdrawalRequestResource extends Resource
{
    protected static ?string $model = WithdrawalRequest::class;
    protected static ?string $navigationIcon = 'heroicon-o-currency-dollar';
    protected static ?string $navigationGroup = 'Finance';

    public static function form(Form $form): Form
    {
        return $form->schema([
            TextInput::make('restaurant.name')->disabled(),
            TextInput::make('amount')->disabled(),
            Select::make('status')
                ->options([
                    'pending'  => 'Pending',
                    'approved' => 'Approved',
                    'declined' => 'Declined',
                    'paid'     => 'Paid',
                ])
                ->required(),
            Textarea::make('admin_notes'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')->sortable(),
                Tables\Columns\TextColumn::make('restaurant.name')->label('Restaurant')->sortable(),
                Tables\Columns\TextColumn::make('amount')->money('usd'),
                Tables\Columns\TextColumn::make('method'),
                Tables\Columns\TextColumn::make('status')->sortable(),
                Tables\Columns\TextColumn::make('created_at')->dateTime(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options([
                        'pending'  => 'Pending',
                        'approved' => 'Approved',
                        'declined' => 'Declined',
                        'paid'     => 'Paid',
                    ]),
            ])
            ->actions([
                Tables\Actions\Action::make('approve')
                    ->label('Approve & Pay')
                    ->requiresConfirmation()
                    ->action(fn(WithdrawalRequest $record) => app(PayoutService::class)->process($record))
                    ->visible(fn($record) => $record->status === 'pending'),
                Tables\Actions\Action::make('decline')
                    ->label('Decline')
                    ->requiresConfirmation()
                    ->action(fn(WithdrawalRequest $record) => $record->update(['status'=>'declined']))
                    ->color('danger')
                    ->visible(fn($record) => $record->status === 'pending'),
            ])
            ->bulkActions([
                Tables\Actions\BulkAction::make('bulkApprove')
                    ->label('Approve & Pay All')
                    ->action(fn($records) => $records->each(fn($r) => app(\App\Services\PayoutService::class)->process($r))),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListWithdrawalRequests::route('/'),
        ];
    }
}
