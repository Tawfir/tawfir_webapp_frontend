<?php

namespace Modules\Admin\Filament\Resources\FoodCategoryResource\Pages;

use Modules\Admin\Filament\Resources\FoodCategoryResource;
use Modules\Admin\Filament\Resources\OrderResource;
use Filament\Resources\Pages\ListRecords;
use Filament\Actions;

class ListFoodCategories extends ListRecords
{
    protected static string $resource = FoodCategoryResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}