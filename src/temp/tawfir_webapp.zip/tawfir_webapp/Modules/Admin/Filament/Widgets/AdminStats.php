<?php

namespace Modules\Admin\Filament\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use Modules\Payment\Entities\WalletTransaction;
use Modules\Restaurant\Entities\Restaurant;
use Modules\User\Entities\Order;
use Modules\User\Entities\User;
use Modules\User\Entities\OrderItem;

class AdminStats extends BaseWidget
{
    protected static ?string $pollingInterval = '30s';

    protected function getStats(): array
    {
        // Calculate total platform service fees earned (7.5% of completed orders)
        $totalRevenue = Order::where('status', 'completed')->sum('total_price');
        $serviceFeePercent = 7.5;
        $platformFeesEarned = ($totalRevenue * $serviceFeePercent) / 100;
        
        // Calculate total surplus items distributed (from completed orders)
        $totalSurplusItemsDistributed = OrderItem::whereHas('order', function($query) {
            $query->where('status', 'completed');
        })->sum('quantity');
        
        // Calculate total CO2 saved from completed orders
        $totalCO2Saved = OrderItem::whereHas('order', function($query) {
            $query->where('status', 'completed');
        })
        ->with('dish')
        ->get()
        ->sum(function($item) {
            return ($item->dish->co2_saved ?? 0) * $item->quantity;
        });
        
        return [
            Stat::make('Registered Restaurants', Restaurant::count())
                ->description('Total restaurants on the platform')
                ->icon('heroicon-o-building-storefront')
                ->color('primary'),
            
            Stat::make('Surplus Items Distributed', $totalSurplusItemsDistributed . ' items')
                ->description('From all completed orders')
                ->icon('heroicon-o-shopping-bag')
                ->color('success'),
            
            Stat::make('Total CO₂ Saved', number_format($totalCO2Saved, 2) . ' kg')
                ->description('Environmental impact across all restaurants')
                ->icon('heroicon-o-globe-alt')
                ->color('success'),
            
            Stat::make('Platform Revenue', '$' . number_format($platformFeesEarned, 2))
                ->description('7.5% service fees earned from restaurants')
                ->icon('heroicon-o-banknotes')
                ->color('primary'),
        ];
    }
}