<?php

namespace Modules\Admin\Filament\Widgets;

use Filament\Widgets\ChartWidget;
use Modules\User\Entities\Order;
use Modules\User\Entities\OrderItem;
use Modules\User\Enums\OrderStatus;

class AdminOverviewChartWidget extends ChartWidget
{
    protected static ?string $pollingInterval = '30s';
    
    public function getHeading(): ?string
    {
        return match($this->filter) {
            'orders' => 'Completed Orders Over Time',
            default => 'Total CO₂ Saved (KG)',
        };
    }
    
    public function getDescription(): ?string
    {
        return match($this->filter) {
            'orders' => 'Number of completed orders across all restaurants',
            default => 'CO₂ saved across all restaurants',
        };
    }

    protected static ?int $sort = 2;

    protected int | string | array $columnSpan = 'full';

    protected static ?string $maxHeight = '400px';
    
    public ?string $filter = 'co2'; // co2, orders
    
    public function updatedFilter(): void
    {
        $this->dispatch('$refresh');
    }

    protected function getData(): array
    {
        // Get orders grouped by date for the last 30 days
        $dates = collect();
        for ($i = 29; $i >= 0; $i--) {
            $dates->push(now()->subDays($i)->format('Y-m-d'));
        }
        
        $co2Data = [];
        $ordersData = [];
        
        foreach ($dates as $date) {
            // Get CO2 saved for this date from all restaurants
            $co2 = OrderItem::whereHas('order', function($query) use ($date) {
                $query->where('status', OrderStatus::COMPLETED->value)
                      ->whereDate('created_at', $date);
            })
            ->with('dish')
            ->get()
            ->sum(function($item) {
                return ($item->dish->co2_saved ?? 0) * $item->quantity;
            });
            
            $co2Data[] = round($co2, 2);
            
            // Get count of completed orders for this date
            $orders = Order::where('status', OrderStatus::COMPLETED->value)
                ->whereDate('created_at', $date)
                ->count();
            
            $ordersData[] = $orders;
        }
        
        $label = match($this->filter) {
            'orders' => 'Completed Orders',
            default => 'CO₂ Saved (KG)',
        };
        
        $dataset = $this->filter === 'co2' ? $co2Data : $ordersData;
        
        return [
            'datasets' => [
                [
                    'label' => $label,
                    'data' => $dataset,
                    'borderColor' => $this->filter === 'co2' 
                        ? 'rgb(34, 197, 94)' // Green for CO2
                        : 'rgb(59, 130, 246)', // Blue for Orders
                    'backgroundColor' => $this->filter === 'co2' 
                        ? 'rgba(34, 197, 94, 0.1)'
                        : 'rgba(59, 130, 246, 0.1)',
                    'fill' => true,
                    'tension' => 0.4,
                    'borderWidth' => 2,
                    'pointRadius' => 3,
                    'pointHoverRadius' => 5,
                ],
            ],
            'labels' => $dates->map(fn($date) => now()->parse($date)->format('M d'))->toArray(),
        ];
    }

    protected function getType(): string
    {
        return 'line';
    }

    protected function getFilters(): ?array
    {
        return [
            'co2' => 'CO₂ Saved',
            'orders' => 'Orders',
        ];
    }

    protected function getOptions(): array
    {
        // Determine the current unit for proper formatting
        $unit = match($this->filter ?? 'co2') {
            'orders' => 'orders',
            default => 'KG',
        };
        
        $label = match($this->filter ?? 'co2') {
            'orders' => 'Completed Orders',
            default => 'CO₂ Saved (KG)',
        };
        
        return [
            'animation' => [
                'duration' => 1000,
                'easing' => 'easeInOutCubic',
                'properties' => ['x', 'y'],
            ],
            'animations' => [
                'x' => [
                    'duration' => 1000,
                    'easing' => 'easeInOutCubic',
                ],
                'y' => [
                    'duration' => 1000,
                    'easing' => 'easeInOutCubic',
                ],
            ],
            'plugins' => [
                'tooltip' => [
                    'enabled' => true,
                    'backgroundColor' => 'rgba(17, 24, 39, 0.95)',
                    'titleColor' => '#F9FAFB',
                    'titleFont' => [
                        'size' => 13,
                        'weight' => '600',
                    ],
                    'bodyColor' => '#D1D5DB',
                    'bodyFont' => [
                        'size' => 13,
                    ],
                    'borderColor' => match($this->filter) {
                        'orders' => 'rgba(59, 130, 246, 0.3)',
                        default => 'rgba(34, 197, 94, 0.3)',
                    },
                    'borderWidth' => 2,
                    'cornerRadius' => 10,
                    'padding' => 14,
                    'displayColors' => false,
                    'callbacks' => [
                        'title' => 'function(context) {
                            return context[0].label;
                        }',
                        'label' => 'function(context) {
                            let value = context.parsed.y;
                            let unit = "' . $unit . '";
                            return "Value: " + value.toFixed(2) + " " + unit;
                        }',
                    ],
                ],
                'legend' => [
                    'display' => false,
                ],
            ],
            'interaction' => [
                'intersect' => false,
                'mode' => 'nearest',
            ],
            'responsive' => true,
            'maintainAspectRatio' => false,
            'elements' => [
                'point' => [
                    'radius' => 4,
                    'hoverRadius' => 6,
                    'hoverBorderWidth' => 2,
                    'borderColor' => '#fff',
                ],
                'line' => [
                    'tension' => 0.4,
                    'borderWidth' => 3,
                    'borderCapStyle' => 'round',
                ],
            ],
            'scales' => [
                'y' => [
                    'beginAtZero' => true,
                    'display' => true,
                    'position' => 'left',
                    'title' => [
                        'display' => false,
                    ],
                    'grid' => [
                        'display' => true,
                        'color' => 'rgba(156, 163, 175, 0.08)',
                        'lineWidth' => 1,
                        'drawBorder' => false,
                    ],
                    'ticks' => [
                        'display' => true,
                        'color' => '#6B7280',
                        'font' => [
                            'size' => 11,
                            'weight' => '500',
                        ],
                        'maxTicksLimit' => 8,
                        'padding' => 8,
                        'stepSize' => match($this->filter) {
                            'orders' => 1,
                            default => null,
                        },
                        'precision' => match($this->filter) {
                            'orders' => 0,
                            default => 1,
                        },
                    ],
                ],
                'x' => [
                    'display' => true,
                    'grid' => [
                        'display' => false,
                    ],
                    'ticks' => [
                        'color' => '#6B7280',
                        'font' => [
                            'size' => 11,
                        ],
                        'maxRotation' => 0,
                        'minRotation' => 0,
                    ],
                ],
            ],
        ];
    }
}

