<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Convert status column from ENUM to VARCHAR to support new enum values
     */
    public function up(): void
    {
        // Use raw SQL to modify the column type from ENUM to VARCHAR
        // This handles cases where the column was created as ENUM with old values
        \DB::statement('ALTER TABLE orders MODIFY COLUMN status VARCHAR(255) NOT NULL DEFAULT "incoming"');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Convert back to ENUM if needed
        \DB::statement("ALTER TABLE orders MODIFY COLUMN status ENUM('incoming', 'ready', 'completed', 'cancelled') NOT NULL DEFAULT 'incoming'");
    }
};
