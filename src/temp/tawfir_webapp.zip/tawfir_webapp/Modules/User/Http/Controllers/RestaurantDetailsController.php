<?php

namespace Modules\User\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\Restaurant\Entities\Restaurant;

class RestaurantDetailsController extends Controller
{
    public function show($id)
    {
        $restaurant = Restaurant::with([
            'dishes' => function ($q) {
                $q->where('quantity', '>', 0);
            },
            'categories'
        ])->findOrFail($id);

        return $this->success([
            'restaurant' => $restaurant,
        ]);
    }
    public function featured()
    {
        $restaurants = Restaurant::where('is_featured', true)
            ->with(['categories'])
            ->latest()
            ->take(10)
            ->get();

        return $this->success([
            'restaurants' => $restaurants,
        ]);
    }

}
