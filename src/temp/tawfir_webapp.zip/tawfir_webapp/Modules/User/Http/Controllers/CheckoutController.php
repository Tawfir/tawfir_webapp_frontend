<?php

namespace Modules\User\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Modules\User\Entities\Order;
use Modules\User\Entities\OrderItem;
use Modules\User\Enums\OrderStatus;

class CheckoutController extends Controller
{
    public function checkout(Request $request)
    {
        $user = $request->user();

        $cartItems = $user->cartItems()->with('dish')->get();

        if ($cartItems->isEmpty()) {
            return $this->error('Cart is empty', 422);
        }

        // Group items by restaurant
        $grouped = $cartItems->groupBy(fn($item) => $item->dish->restaurant_id);

        $orders = [];

        DB::beginTransaction();

        try {
            foreach ($grouped as $restaurantId => $items) {
                $total = 0;
                $pickupTime = null;

                $order = Order::create([
                    'user_id'       => $user->id,
                    'restaurant_id' => $restaurantId,
                    'total_price'   => 0,
                    'pickup_time'   => $items->first()->dish->pickup_time ?? now()->addHour(),
                    'status'        => OrderStatus::INCOMING,
                ]);

                foreach ($items as $item) {
                    $dish = $item->dish;
                    $price = $dish->discounted_price ?? $dish->price;

                    // 🛑 Check if quantity is enough
                    if ($dish->quantity < $item->quantity) {
                        DB::rollBack(); // Cancel everything
                        return $this->error('Not enough quantity for ' . $dish->name, 422);
                    }

                    OrderItem::create([
                        'order_id'             => $order->id,
                        'dish_id'              => $dish->id,
                        'quantity'             => $item->quantity,
                        'price_at_order_time'  => $price,
                    ]);

                    $total += $price * $item->quantity;

                    // Decrease available quantity
                    $dish->decrement('quantity', $item->quantity);
                }

                $order->update(['total_price' => $total]);

                $orders[] = $order->load('items.dish');
            }


            // Clear user's cart
            $user->cartItems()->delete();

            DB::commit();

            return $this->success([
                'orders' => $orders,
            ], 'Checkout successful');
        } catch (\Throwable $e) {
            DB::rollBack();
            return $this->error('Checkout failed: ' . $e->getMessage(), 500);
        }
    }
}
