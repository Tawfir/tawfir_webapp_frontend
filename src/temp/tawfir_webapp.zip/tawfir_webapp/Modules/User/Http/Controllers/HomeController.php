<?php

namespace Modules\User\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Modules\Restaurant\Entities\Dish;
use Modules\Restaurant\Entities\FoodCategory;
use Modules\Restaurant\Entities\Restaurant;
use Modules\User\Entities\Order;
use Modules\User\Entities\OrderItem;

class HomeController extends Controller
{
    public function home(Request $request)
    {
        // 1️⃣ Top 5 dishes by order count
        $topDishes = Dish::with('restaurant', 'categories')
            ->withCount('orders')
            ->orderByDesc('orders_count')
            ->take(5)
            ->get();

        // 2️⃣ Get 3 random dishes from user's order history
        $userOrderHistoryDishes = collect();
        $user = $request->user();

        if ($user) {
            $userOrderHistoryDishes = Dish::with('restaurant', 'categories')
                ->whereIn('id', function ($query) use ($user) {
                    $query->select('dish_id')
                          ->from('order_items')
                          ->whereIn('order_id', function ($subQuery) use ($user) {
                              $subQuery->select('id')
                                      ->from('orders')
                                      ->where('user_id', $user->id);
                          });
                })
                ->inRandomOrder()
                ->take(3)
                ->get()
                ->map(function ($dish) {
                    $dish->is_from_order_history = true;
                    return $dish;
                });
        }

        // 3️⃣ Merge top dishes with order history dishes
        $combinedTopDishes = $topDishes->merge($userOrderHistoryDishes);

        // 4️⃣ All categories (id, name, image)
        $categories = FoodCategory::select('id', 'name', 'image')->get();

        // 5️⃣ Random 6 dishes
        $randomDishes = Dish::with('restaurant', 'categories')->inRandomOrder()->take(6)->get();

        // 6️⃣ Nearby restaurants if lat/lng provided
        $nearby = [];
        if ($request->filled('lat') && $request->filled('lng')) {
            $request->validate([
                'lat' => 'numeric|between:-90,90',
                'lng' => 'numeric|between:-180,180',
            ]);

            [$lat, $lng] = [$request->lat, $request->lng];

            $nearby = Restaurant::selectRaw(
                "*, (6371 * acos(
                        cos(radians(?)) *
                        cos(radians(lat)) *
                        cos(radians(lng) - radians(?)) +
                        sin(radians(?)) *
                        sin(radians(lat))
                    )) AS distance",
                [$lat, $lng, $lat]
            )
                ->having('distance', '<=', 20)
                ->orderBy('distance')
                ->with('categories')
                ->get();
        }

        // 7️⃣ Unread notifications count
        $unreadCount = $request->user()->unreadNotifications()->count();

        // 8️⃣ Return everything in one envelope
        return $this->success([
            'top_dishes'           => $combinedTopDishes,
            'categories'           => $categories,
            'random_dishes'        => $randomDishes,
            'nearby_restaurants'   => $nearby,
            'unread_notifications' => $unreadCount,
        ], 'Home data retrieved successfully');
    }


    public function categories(Request $request)
    {
        $search = $request->input('search', '');
        // Fetch all categories with their image URLs
        $categories = FoodCategory::select('id', 'name', 'image')
            ->when($search, function ($query) use ($search) {
                return $query->where('name', 'like', "%{$search}%");
            })
            ->orderBy('name')
            ->get();

        // Return the categories in a success response
        return $this->success($categories, 'Categories retrieved successfully');
    }
    public function search(Request $request)
    {
        // 1️⃣ Validate input
        $data = $request->validate([
            'search'         => 'nullable|string',
            'lat'       => 'nullable|numeric|between:-90,90',
            'lng'       => 'nullable|numeric|between:-180,180',
            'paginated' => 'nullable|boolean',
        ]);

        $user      = $request->user();
        $lat       = $data['lat'] ?? $user->lat;
        $lng       = $data['lng'] ?? $user->lng;
        $paginate  = $request->boolean('paginated');

        if (is_null($lat) || is_null($lng)) {
            return $this->error(__('Latitude and longitude are required'), 422);
        }

        $h = "(6371 * acos(
            cos(radians(?)) *
            cos(radians(lat)) *
            cos(radians(lng) - radians(?)) +
            sin(radians(?)) *
            sin(radians(lat))
        ))";

        // Build restaurant query - includes restaurants with matching names OR restaurants that have dishes with matching names
        $restQ = Restaurant::selectRaw("restaurants.*, {$h} as distance", [$lat, $lng, $lat]);
        if (!empty($data['search'])) {
            $restQ->where(function ($query) use ($data) {
                $query->where('restaurants.name', 'like', "%{$data['search']}%")
                      ->orWhereExists(function ($subQuery) use ($data) {
                          $subQuery->select(DB::raw(1))
                                   ->from('dishes')
                                   ->whereColumn('dishes.restaurant_id', 'restaurants.id')
                                   ->where('dishes.name', 'like', "%{$data['search']}%");
                      });
            });
        }
        $restQ->orderBy('distance');

        // Build dish query - dishes with matching names
        $dishQ = Dish::selectRaw("dishes.*, {$h} as distance", [$lat, $lng, $lat])
            ->join('restaurants', 'dishes.restaurant_id', '=', 'restaurants.id');
        if (!empty($data['search'])) {
            $dishQ->where('dishes.name', 'like', "%{$data['search']}%");
        }
        $dishQ->orderBy('distance');

        // Execute
        if ($paginate) {
            $perPage = $request->input('per_page', 10);
            $restaurants = $restQ->paginate($perPage);
            $dishes      = $dishQ->with('restaurant')->paginate($perPage);
        } else {
            $restaurants = $restQ->get();
            $dishes      = $dishQ->with('restaurant')->get();
        }

        return $this->success([
            'restaurants' => $restaurants,
            'dishes'      => $dishes,
        ], __('Search results'));
    }


    public function categoryDishes(Request $request, $id)
    {
        // 1️⃣ Validate
        $data = $request->validate([
            'lat'       => 'nullable|numeric|between:-90,90',
            'lng'       => 'nullable|numeric|between:-180,180',
            'paginated' => 'nullable|boolean',
        ]);

        $category = FoodCategory::find($id);
        if (! $category) {
            return $this->error(__('Category not found'), 404);
        }

        $user     = $request->user();
        $lat      = $data['lat'] ?? $user->lat;
        $lng      = $data['lng'] ?? $user->lng;
        $paginate = $request->boolean('paginated');

        if (is_null($lat) || is_null($lng)) {
            return $this->error(__('Latitude and longitude are required'), 422);
        }

        $h = "(6371 * acos(
            cos(radians(?)) *
            cos(radians(lat)) *
            cos(radians(lng) - radians(?)) +
            sin(radians(?)) *
            sin(radians(lat))
        ))";

        // Restaurants in this category
        $restQ = Restaurant::selectRaw("restaurants.*, {$h} as distance", [$lat, $lng, $lat])
            ->join('dishes', 'restaurants.id', '=', 'dishes.restaurant_id')
            ->join('food_category_dish', 'dishes.id', '=', 'food_category_dish.dish_id')
            ->where('food_category_dish.food_category_id', $id)
            ->groupBy('restaurants.id')
            ->orderBy('distance');

        // Dishes in this category
        $dishQ = Dish::selectRaw("dishes.*, {$h} as distance", [$lat, $lng, $lat])
            ->join('restaurants', 'dishes.restaurant_id', '=', 'restaurants.id')
            ->join('food_category_dish', 'dishes.id', '=', 'food_category_dish.dish_id')
            ->where('food_category_dish.food_category_id', $id)
            ->orderBy('distance');

        // Execute
        if ($paginate) {
            $perPage = $request->input('per_page', 10);
            $restaurants = $restQ->paginate($perPage);
            $dishes      = $dishQ->with('restaurant')->paginate($perPage);
        } else {
            $restaurants = $restQ->get();
            $dishes      = $dishQ->with('restaurant')->get();
        }

        return $this->success([
            'restaurants' => $restaurants,
            'dishes'      => $dishes,
        ], __('Nearby results for category'));
    }

}
