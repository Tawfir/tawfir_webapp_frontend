<?php

namespace Modules\User\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Services\WalletService;
use Modules\User\Enums\OrderStatus;
use Stripe\Refund;
use Stripe\Stripe;

class OrdersController extends Controller
{
    public function index(Request $request)
    {
        $orders = $request->user()
            ->orders()
            ->with(['restaurant', 'items.dish'])
            ->latest()
            ->get();

        return $this->success([
            'orders' => $orders
        ], 'Orders retrieved successfully');
    }

    public function show(Request $request, $id)
    {
        $order = $request->user()
            ->orders()
            ->with(['restaurant', 'items.dish'])
            ->findOrFail($id);

        return $this->success([
            'order' => $order
        ], 'Order retrieved successfully');
    }

    public function cancel(Request $request, $id)
    {
        $order = $request->user()
            ->orders()
            ->with(['restaurant'])
            ->findOrFail($id);
        // 1. Only allow cancelling if still 'incoming'
        if ($order->status !== OrderStatus::INCOMING->value) {
            return response()->json([
                'status'  => false,
                'message' => 'You can only cancel incoming orders.'
            ], 422);
        }

        // 2. Find the payment transaction
        $txn = Transaction::where('order_id', $order->id)
            ->where('status', 'succeeded')
            ->first();

        // 3. If Stripe, issue a refund immediately
        if ($txn && $txn->method === 'stripe' && $txn->gateway_id) {
            Stripe::setApiKey(env('STRIPE_SECRET'));
            Refund::create([
                'payment_intent' => $txn->gateway_id,
            ]);
            // update txn status
            $txn->update(['status' => 'refunded']);
        }

        // 4. Compute fees & net amounts
        $total    = $order->total_price;
        $feePct   = config('payment.service_fee_percent');
        $service  = ($total * $feePct) / 100;
        $netToRest = $total - $service;

        // 5. Reverse restaurant wallet (debit)
        WalletService::debit(
            $order->restaurant,
            $netToRest,
            "Refund Order #{$order->id}",
            $order->id
        );

        // 6. Credit the user’s wallet with full amount (food + fee)
        WalletService::credit(
            $order->user,
            $total + $service,
            "Refund Order #{$order->id}",
            $order->id
        );

        // 7. Mark the order cancelled
        $order->update(['status' => OrderStatus::CANCELLED->value]);

        return response()->json([
            'status'  => true,
            'message' => 'Order cancelled and refunded.',
        ]);
    }
}
