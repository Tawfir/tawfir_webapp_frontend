<?php

namespace Modules\User\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\Restaurant\Entities\FoodCategory;

class FoodCategoryController extends Controller
{
    public function index()
    {
        return response()->json(FoodCategory::all());
    }

    public function search(Request $request)
    {
        return response()->json(
            FoodCategory::where('name','like',"%{$request->q}%")->get()
        );
    }

    public function dishesByCategory(FoodCategory $category, Request $request)
    {
        $dishes = $category->dishes()
            ->with('restaurant')
            ->orderByDistance($request->lat,$request->lng)
            ->paginate();
        return response()->json($dishes);
    }
}
