<?php

namespace Modules\User\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AccountController extends Controller
{
    public function destroy(Request $request)
    {
        // dispatch a deletion request, or soft-delete user
        auth()->user()->delete();
        return response()->json(['message'=>'Account deletion requested'], 202);
    }
}
