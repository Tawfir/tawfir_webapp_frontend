<?php

namespace Modules\User\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Modules\Restaurant\Entities\Dish;
use Modules\User\Entities\Cart;

class CartController extends Controller
{
    public function index(Request $request)
    {
        $cartItems = $request->user()->cartItems()->with('dish','dish.restaurant')->get();

        return $this->success(['items' => $cartItems],
            'Cart items retrieved successfully');
    }

    public function add(Request $request)
    {
        $data = $request->validate([
            'dish_id'  => 'required|exists:dishes,id',
            'quantity' => 'nullable|integer|min:1',
        ]);

        $user      = $request->user();
        $dish      = Dish::findOrFail($data['dish_id']);
        $qtyToAdd  = $data['quantity'] ?? 1;

        // if mixing restaurants, wipe existing cart
        $firstItem = $user->cartItems()->with('dish')->first();
        if ($firstItem && $firstItem->dish->restaurant_id !== $dish->restaurant_id) {
            $user->cartItems()->delete();
        }

        return DB::transaction(function() use ($user, $dish, $qtyToAdd) {
            $cartItem = Cart::firstOrNew([
                'user_id' => $user->id,
                'dish_id' => $dish->id,
            ]);

            $newTotal = ($cartItem->quantity ?? 0) + $qtyToAdd;
            if ($newTotal > $dish->quantity) {
                return $this->error('Requested quantity exceeds available stock', 400);
            }

            $cartItem->quantity = $newTotal;
            $cartItem->save();

            return $this->success(
                $user->cartItems()->with('dish')->get(),
                'Item added to cart successfully'
            );
        });
    }


    public function remove(Request $request)
    {
        $data = $request->validate([
            'dish_id'  => 'required|exists:dishes,id',
            'quantity' => 'nullable|integer|min:1',
        ]);

        $user = $request->user();
        $cartItem = $user->cartItems()->where('dish_id', $data['dish_id'])->first();

        if (! $cartItem) {
            return $this->error('Item not found in cart', 404);
        }

        // Determine how many to remove (all if not specified)
        $qtyToRemove = $data['quantity'] ?? $cartItem->quantity;

        if ($qtyToRemove >= $cartItem->quantity) {
            // Remove the whole row
            $cartItem->delete();
        } else {
            // Just decrement
            $cartItem->decrement('quantity', $qtyToRemove);
        }

        return $this->success($user->cartItems()->with('dish')->get(), 'Item removed from cart successfully');
    }

    // empty the cart
    public function flush(Request $request)
    {
        $user = $request->user();
        $user->cartItems()->delete();

        return $this->success([], 'Cart emptied successfully');
    }
}
