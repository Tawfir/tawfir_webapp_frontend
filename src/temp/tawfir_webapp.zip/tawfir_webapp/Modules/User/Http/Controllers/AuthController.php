<?php

namespace Modules\User\Http\Controllers;

use App\Enums\UserType;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Modules\Notifications\Notifications\ResetPasswordCode;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $data = $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|email|unique:users',
            'phone'    => 'required|string|unique:users',
            'password' => 'required|string|min:6',
            'onesignal_user_id' => 'nullable|string',
        ]);

        $user = User::create([
            'name'     => $data['name'],
            'email'    => $data['email'],
            'phone'    => $data['phone'],
            'password' => bcrypt($data['password']),
            'type'     => UserType::USER->value,
            'onesignal_user_id' => $request->onesignal_user_id, // ✅ Add this
        ]);



        $user->addRole('user');

        $token = $user->createToken('user-token')->plainTextToken;

        return $this->success([
            'user'  => $user,
            'token' => $token,
        ], 'Registration successful');

    }

    public function login(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required|string',
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }
        if ($request->filled('onesignal_user_id')) {
            $user->update([
                'onesignal_user_id' => $request->onesignal_user_id,
            ]);
        }

        $token = $user->createToken('user-token')->plainTextToken;

        return $this->success([
            'user'  => $user,
            'token' => $token,
        ], 'Login successful');

    }

    public function logout(Request $request)
    {
        $request->user()->tokens()->delete();

        return $this->success(null, 'Logged out successfully');
    }

    public function getUser(Request $request)
    {
        return $this->success($request->user());
    }

    public function updateProfile(Request $request)
    {
        $user = $request->user();

        $data = $request->validate([
            'name'  => 'nullable|string|max:255',
            'email' => 'nullable|email|unique:users,email,' . $user->id,
            'phone' => 'nullable|string|unique:users,phone,' . $user->id,
            'lat'   => 'nullable|numeric|between:-90,90',
            'lng'   => 'nullable|numeric|between:-180,180',
        ]);


        $user->update(array_filter($data)); // only update non-null values

        return $this->success([
            'user' => $user,
        ], 'Profile updated successfully');
    }

    public function requestPasswordResetCode(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
        ]);

        // 1. generate 6-digit code
        $code = random_int(100000, 999999);

        // 2. upsert into password_resets table
        DB::table('password_resets')->updateOrInsert(
            ['email' => $request->email],
            [
                'token'      => $code,
                'created_at' => now(),
            ]
        );

        // 3. notify user (email, database, OneSignal)
        $user = User::where('email', $request->email)->first();
        $user->notify(new ResetPasswordCode($code));

        return $this->success(null, 'Password reset code sent.');
    }

    public function resetPasswordWithCode(Request $request)
    {
        $data = $request->validate([
            'email'                 => 'required|email|exists:users,email',
            'code'                  => 'required|digits:6',
            'password'              => 'required|string|min:6|confirmed',
        ]);

        // fetch the reset row
        $row = DB::table('password_resets')
            ->where('email', $data['email'])
            ->where('token', $data['code'])
            ->first();

        // check existence & expiry (uses your config password expire minutes, e.g. 60)
        $expires = config('auth.passwords.users.expire');
        if (! $row || Carbon::parse($row->created_at)->addMinutes($expires)->isPast()) {
            throw ValidationException::withMessages([
                'code' => ['Invalid or expired reset code.'],
            ]);
        }

        // update user password
        $user = User::where('email', $data['email'])->first();
        $user->password = bcrypt($data['password']);
        $user->save();

        // cleanup
        DB::table('password_resets')->where('email', $data['email'])->delete();

        return $this->success(null, 'Password has been reset.');
    }


}
