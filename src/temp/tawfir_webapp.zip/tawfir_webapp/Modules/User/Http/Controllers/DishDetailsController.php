<?php

namespace Modules\User\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\Restaurant\Entities\Dish;

class DishDetailsController extends Controller
{
    public function show($id)
    {
        $dish = Dish::with(['restaurant', 'categories'])->findOrFail($id);

        return $this->success([
            'dish' => $dish
        ]);
    }
}
