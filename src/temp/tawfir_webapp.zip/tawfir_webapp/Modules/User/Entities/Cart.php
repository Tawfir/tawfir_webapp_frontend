<?php

namespace Modules\User\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Cart extends Model
{
    protected $fillable = [
        'user_id',
        'dish_id',
        'quantity',
    ];

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function dish()
    {
        return $this->belongsTo(\Modules\Restaurant\Entities\Dish::class);
    }
}
