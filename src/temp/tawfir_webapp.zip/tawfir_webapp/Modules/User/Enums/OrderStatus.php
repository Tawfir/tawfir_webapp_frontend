<?php

namespace Modules\User\Enums;

enum OrderStatus: string
{
    case INCOMING = 'incoming';
    case READY = 'ready';
    case COMPLETED = 'completed';
    case CANCELLED = 'cancelled';
}