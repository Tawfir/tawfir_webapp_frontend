<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\User\Http\Controllers\AuthController;
use Modules\User\Http\Controllers\CartController;
use Modules\User\Http\Controllers\CheckoutController;
use Modules\User\Http\Controllers\DishDetailsController;
use Modules\User\Http\Controllers\HomeController;
use Modules\User\Http\Controllers\OrdersController;
use Modules\User\Http\Controllers\RestaurantDetailsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::name('user.')->prefix('user')->group(function () {
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('dishes/{id}', [DishDetailsController::class, 'show']);
        Route::get('restaurants/featured', [RestaurantDetailsController::class, 'featured']);
        Route::get('restaurants/{id}', [RestaurantDetailsController::class, 'show']);

        Route::name('cart.')->prefix('cart')->group(function () {
            Route::get('', [CartController::class, 'index'])->name('index');
            Route::post('/add', [CartController::class, 'add'])->name('add');
            Route::post('/remove', [CartController::class, 'remove'])->name('remove');
            Route::post('/flush', [CartController::class, 'flush'])->name('flush');

            //Route::post('/checkout', [CheckoutController::class, 'checkout'])->name('checkout');
        });

        Route::name('orders.')->prefix('orders')->group(function () {
            Route::post('/{id}/cancel', [OrdersController::class, 'cancel']);

            Route::get('', [OrdersController::class, 'index'])->name('index');
            Route::get('/{id}', [OrdersController::class, 'show'])->name('show');
        });
        Route::name('home.')->prefix('/home')->group(function () {
            Route::get('/', [HomeController::class, 'home'])->name('index');
            Route::get('search', [HomeController::class, 'search'])
                ->name('search');
        });
        Route::name('categories.')->prefix('/categories')->group(function () {
            Route::get('/', [HomeController::class, 'categories'])->name('index');
            Route::get('/{id}/dishes', [HomeController::class, 'categoryDishes'])
                ->name('dishes');
        });

    });

});
