<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // make co2_saved column double instead of float
        Schema::table('dishes', function (Blueprint $table) {
            $table->double('co2_saved', 8, 2)->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // revert co2_saved column back to float
        Schema::table('dishes', function (Blueprint $table) {
            $table->float('co2_saved')->change();
        });
    }
};
