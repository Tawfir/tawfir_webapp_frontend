<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Services\WalletService;
use Modules\Restaurant\Entities\Dish;
use Modules\Restaurant\Entities\Restaurant;
use Modules\User\Entities\Order;
use Modules\User\Entities\OrderItem;
use Modules\User\Enums\OrderStatus;

class OrderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = \App\Models\User::where('email', 'user@example.com')->first();
        $restaurant = Restaurant::first();
        $dishes = Dish::all();

        // Define order distribution for today: few incoming, few ready, more completed
        $todayOrders = [
            ['status' => OrderStatus::INCOMING, 'count' => 6],
            ['status' => OrderStatus::READY, 'count' => 4],
            ['status' => OrderStatus::COMPLETED, 'count' => 12],
        ];

        $pickupTimes = ['11:00', '11:30', '12:00', '12:30', '13:00', '13:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30'];

        // Create orders for each status
        foreach ($todayOrders as $orderGroup) {
            for ($i = 0; $i < $orderGroup['count']; $i++) {
                // Pick random dishes (1-4 dishes per order)
                $numberOfDishes = rand(1, 4);
                $selectedDishes = $dishes->random($numberOfDishes);

                $totalPrice = 0;
                
                // For today's orders, use today's date with random times throughout the day
                $createdAt = Carbon::today()->addHours(rand(9, 22))->addMinutes(rand(0, 59));
                
                $order = Order::create([
                    'user_id' => $user->id,
                    'restaurant_id' => $restaurant->id,
                    'status' => $orderGroup['status']->value,
                    'pickup_time' => $pickupTimes[array_rand($pickupTimes)],
                    'total_price' => 0, // Will update after
                    'created_at' => $createdAt,
                ]);

                foreach ($selectedDishes as $dish) {
                    $quantity = rand(1, 3);
                    $price = $dish->discounted_price ?? $dish->price;
                    $itemTotal = $price * $quantity;
                    $totalPrice += $itemTotal;

                    OrderItem::create([
                        'order_id' => $order->id,
                        'dish_id' => $dish->id,
                        'quantity' => $quantity,
                        'price_at_order_time' => $price,
                    ]);
                }

                // Update order with total price
                $order->update(['total_price' => $totalPrice]);
                
                // Refresh the order to ensure proper enum casting
                $order->refresh();

                // Create transaction for completed orders to credit wallet
                $orderStatus = is_object($order->status) ? $order->status->value : $order->status;
                if ($orderStatus === 'completed' || $orderStatus === OrderStatus::COMPLETED->value) {
                    $this->command->info("Crediting wallet for Order #{$order->id} with amount: $" . $totalPrice);
                    // Create a cash transaction
                    Transaction::create([
                        'order_id' => $order->id,
                        'user_id' => $user->id,
                        'amount_cents' => $totalPrice * 100,
                        'currency' => 'usd',
                        'type' => 'payment',
                        'method' => 'cash',
                        'status' => 'succeeded',
                    ]);

                    // Calculate net amount (after service fee)
                    $feePct = config('payment.service_fee_percent', 7.5);
                    $serviceFee = ($totalPrice * $feePct) / 100;
                    $netToRestaurant = $totalPrice - $serviceFee;

                    // Credit restaurant wallet
                    WalletService::credit(
                        $restaurant,
                        $netToRestaurant,
                        "Order #{$order->id} (cash)",
                        $order->id
                    );
                    
                    $this->command->info("Wallet credited: $" . $netToRestaurant);
                }
            }
        }

        $this->command->info('22 dummy orders created successfully for today!');
    }
}
