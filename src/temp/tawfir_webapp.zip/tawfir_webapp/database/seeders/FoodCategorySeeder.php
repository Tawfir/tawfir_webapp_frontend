<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Modules\Restaurant\Entities\FoodCategory;

class FoodCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            'Burgers',
            'Salads & Bowls',
            'Drinks',
            'Desserts',
            'Hot Meals',
            'Sandwiches & Wraps'
        ];

        foreach ($categories as $name) {
            FoodCategory::updateOrCreate(
                [
                    'name' => $name,
                    'slug' => Str::slug($name),
                ],
                [
                'name' => $name,
                'slug' => Str::slug($name),
            ]);
        }
    }
}
