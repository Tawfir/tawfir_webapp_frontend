<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Modules\Restaurant\Entities\Dish;
use Modules\Restaurant\Entities\Restaurant;
use Modules\Restaurant\Enums\RestaurantStatus;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        // Uncomment the following lines to run the seeders
         $this->call(RoleSeeder::class);
            $this->call(FoodCategorySeeder::class);
        // Create Admin
        $admin = User::updateOrCreate(
            [            'email' => 'admin@example.com',
                ],
                [
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'type' => 'admin',
            'password' => Hash::make('password'),
        ]);
        $admin->syncRoles(['admin']);

        // Create Normal User
        $user = User::updateOrCreate(
            [
                'email' => 'user@example.com',
            ],
            [
            'name' => 'Normal User',
            'email' => 'user@example.com',
            'type' => 'user',
            'password' => Hash::make('password'),
        ]);
        // add role to user even if it exists
        $user->syncRoles(['user']);

        // Create Restaurant Owner
        $restaurantUser = User::updateOrCreate(
            [
                'email' => 'restaurant@example.com',

            ],
            [
            'name' => 'Restaurant Owner',
            'email' => 'restaurant@example.com',
            'type' => 'restaurant',
            'password' => Hash::make('password'),
        ]);
        $restaurantUser->syncRoles(['restaurant']);

        // Create Restaurant
        $restaurant = Restaurant::create([
            'user_id' => $restaurantUser->id,
            'name' => 'Tawfir Restaurant',
            'address' => '123 Test Street',
            'lat' => 24.7136,
            'lng' => 46.6753,
            'public_phone' => '0500000000',
            'private_phone' => '0550000000',
            'status' => RestaurantStatus::APPROVED,
            'is_featured' => true,
        ]);

        // Create Sample Dishes
        $dishes = [
            // Sandwiches & Wraps (category_id: 1)
            ['name' => 'Chicken Sandwhich', 'price' => 10.00, 'discounted_price' => 5.00, 'quantity' => 5, 'pickup_time' => '22:00', 'category_id' => 1],
            ['name' => 'Falafel Sandwhich', 'price' => 10.00, 'discounted_price' => 5.00, 'quantity' => 10, 'pickup_time' => '10:00', 'category_id' => 1],
            
            // Drinks (category_id: 2)
            ['name' => 'Fresh Orange Juice', 'price' => 5.00, 'discounted_price' => 2.50, 'quantity' => 0, 'pickup_time' => '20:00', 'category_id' => 2],
            ['name' => 'Iced Latte', 'price' => 15.00, 'discounted_price' => 7.50, 'quantity' => 5, 'pickup_time' => '20:30', 'category_id' => 2],
            
            // Desserts (category_id: 3)
            ['name' => 'Chocolate Mousse', 'price' => 15.00, 'discounted_price' => 7.50, 'quantity' => 0, 'pickup_time' => '21:30', 'category_id' => 3],
            ['name' => 'Cheesecake', 'price' => 10.00, 'discounted_price' => 5.00, 'quantity' => 0, 'pickup_time' => '21:30', 'category_id' => 3],
            
            // Burgers (category_id: 4)
            ['name' => 'Chicken Burger', 'price' => 20.00, 'discounted_price' => 10.00, 'quantity' => 0, 'pickup_time' => '18:00', 'category_id' => 4],
            ['name' => 'Veggie Burger', 'price' => 15.00, 'discounted_price' => 7.50, 'quantity' => 4, 'pickup_time' => '18:00', 'category_id' => 4],
            
            // Hot Meals (category_id: 5)
            ['name' => 'Mac & Cheese Pasta', 'price' => 20.00, 'discounted_price' => 10.00, 'quantity' => 30, 'pickup_time' => '22:00', 'category_id' => 5],
            ['name' => 'Chicken Biryani', 'price' => 15.00, 'discounted_price' => 7.50, 'quantity' => 10, 'pickup_time' => '21:00', 'category_id' => 5],
            
            // Salads & Bowls (category_id: 6)
            ['name' => 'Chicken Ceasar Salad', 'price' => 20.00, 'discounted_price' => 10.00, 'quantity' => 5, 'pickup_time' => '20:00', 'category_id' => 6],
            ['name' => 'Quinoa Veg Salad', 'price' => 15.00, 'discounted_price' => 7.50, 'quantity' => 0, 'pickup_time' => '20:00', 'category_id' => 6],
        ];

        foreach ($dishes as $dishData) {
            $dish = Dish::create([
                'restaurant_id' => $restaurant->id,
                'name' => $dishData['name'],
                'price' => $dishData['price'],
                'discounted_price' => $dishData['discounted_price'],
                'co2_saved' => rand(5, 50) / 10, // Random CO2 saved between 0.5 and 5.0 kg
                'availability_method' => 'pickup',
                'quantity' => $dishData['quantity'],
                'pickup_time' => $dishData['pickup_time'],
                'image' => 'https://via.placeholder.com/300',
            ]);
            
            // Attach category to the dish
            $dish->categories()->attach($dishData['category_id']);
        }

        // Create dummy orders after dishes are created
        $this->call(OrderSeeder::class);

        $this->command->info('Default users, restaurant, and dishes created.');
    }
}
