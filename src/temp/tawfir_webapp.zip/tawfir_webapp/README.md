# TAWFIR - Admin/Restaurant Portals

This is a repo containing the main admin and restaurant portal management for the overall application. 

Follow these steps to run the application locally on your machine.

## Prerequisites
- PHP 8.1 or higher
- Composer
- Node.js and npm
- MySQL (via XAMPP or standalone)

## Setup Instructions

### 1. Install Dependencies
```bash
composer install
npm install
```

### 2. Environment Configuration
```bash
copy .env.example .env
php artisan key:generate
```

Edit the `.env` file and configure your database:
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3307
DB_DATABASE=laravel
DB_USERNAME=root
DB_PASSWORD=
```

### 3. Create Database
- Start MySQL & Apache in XAMPP Control Panel
- Open phpMyAdmin at http://localhost/phpmyadmin
- Create a new database (e.g., `laravel`)

### 4. Runs Migrations and Seeders
```bash
# Recreates all schemas and seeders to populate from scratch
php artisan migrate:fresh --seed

# Runs the seeders only (requires tables to be created and aligned)
php artisan db:seed
```

### 5. Publish Filament Assets
```bash
php artisan filament:assets
```

### 6. Start Development Servers

**Terminal 1 - Laravel Server:**
```bash
php artisan serve
```

**Terminal 2 - Vite (Asset Compiler):**
```bash
npm run dev
```

### 7. Access the Application

- **Admin Panel:** http://127.0.0.1:8000/admin
- **Restaurant Panel:** http://127.0.0.1:8000/restaurant

**Login Credentials:**
- Email: `admin@example.com`
- Password: `password`

- Email: `restaurant@example.com`
- Password: `password`

## Notes

- Keep both terminal windows running while developing
- The application is configured to run on HTTP in local environment (not HTTPS)
- Assets are automatically compiled by Vite in watch mode
