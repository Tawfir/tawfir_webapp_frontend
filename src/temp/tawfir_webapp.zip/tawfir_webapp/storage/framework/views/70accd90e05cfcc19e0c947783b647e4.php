<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\adi\Desktop\Tawfir\tawfir_webapp\vendor\filament\support\src\/../resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>