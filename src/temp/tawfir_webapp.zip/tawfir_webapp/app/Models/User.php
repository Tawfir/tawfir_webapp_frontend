<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use App\Enums\UserType;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Laratrust\Contracts\LaratrustUser;
use Laratrust\Traits\HasRolesAndPermissions;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Modules\Payment\Entities\WalletTransaction;

class User extends Authenticatable implements LaratrustUser
{
    use HasApiTokens, HasFactory, Notifiable,HasRolesAndPermissions,SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $guarded = [];
    protected static function booted()
    {
        static::deleting(function (User $user) {
            // when user->delete() is called, soft-delete all their orders
            $user->orders()->delete();
        });

        // if you ever forceDelete the user, also forceDelete orders:
        static::forceDeleted(function (User $user) {
            $user->orders()->withTrashed()->forceDelete();
        });
    }

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'type' => UserType::class,
    ];

    public function restaurant()
    {
        return $this->hasOne(\Modules\Restaurant\Entities\Restaurant::class);
    }

    public function cartItems()
    {
        return $this->hasMany(\Modules\User\Entities\Cart::class);
    }
    public function orders()
    {
        return $this->hasMany(\Modules\User\Entities\Order::class);
    }

    public function walletTransactions()
    {
        return $this->morphMany(WalletTransaction::class, 'walletable');
    }

    public function routeNotificationForOneSignal(): array
    {
        // This tells the channel to include your OneSignal user by the external_user_id you set in Flutter
        return ['include_external_user_ids' => [(string) $this->id]];
    }
}
