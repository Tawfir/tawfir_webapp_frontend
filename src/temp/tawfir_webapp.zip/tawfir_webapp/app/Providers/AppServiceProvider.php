<?php

namespace App\Providers;

use Filament\Support\Colors\Color;
use Filament\Support\Facades\FilamentColor;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;
use Laravel\Telescope\Telescope;
use Modules\Notifications\Observers\OrderObserver;
use Modules\User\Entities\Order;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //Telescope::filter(function ($request) {
        //    return app()->isLocal(); // Change this if you want to allow on staging or production
        //});
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        if (app()->environment('production')) {
            URL::forceScheme('https');
        }
        FilamentColor::register([
            'primary' => Color::hex('#59a817'),
        ]);
        Order::observe(OrderObserver::class);

    }
}
