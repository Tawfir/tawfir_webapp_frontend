<?php

namespace App\Providers\Filament;

use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Pages;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\Widgets;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;
use Modules\Restaurant\Filament\Widgets\OrderStatusChartWidget;
use Modules\Restaurant\Filament\Widgets\RestaurantStatsWidget;
use Modules\Restaurant\Filament\Widgets\SurplusStatsWidget;
use Modules\Restaurant\Filament\Widgets\WalletBalanceWidget;
use Modules\Restaurant\Filament\Widgets\WasteSavedChartWidget;
use Modules\Restaurant\Filament\Widgets\WelcomeWidget;
use Modules\Restaurant\Filament\Widgets\WithdrawalRequestsWidget;

class RestaurantPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->id('restaurant')
            ->path('restaurant')
            ->brandName('Tawfir Restaurant Portal')
            ->favicon('logo.png')
            ->login()
            ->authGuard('restaurant')
            ->authPasswordBroker('restaurants')
            //->colors([
            //    'primary' => Color::Amber,
            //])
            ->discoverResources(
                in: base_path('Modules/Restaurant/Filament/Resources'),
                for: 'Modules\\Restaurant\\Filament\\Resources',
            )
            ->discoverPages(
                in: app_path('Modules/Restaurant/Filament/Pages'),
                for: 'Modules\\Restaurant\\Filament\\Pages')
            ->pages([
                Pages\Dashboard::class,
            ])
            ->discoverWidgets(
                in: app_path('Modules/Restaurant/Filament/Widgets'),
                for: 'Modules\\Restaurant\\Filament\\Widgets')
            ->widgets([
                WelcomeWidget::class,
                WasteSavedChartWidget::class,
                OrderStatusChartWidget::class,
                SurplusStatsWidget::class,
                WithdrawalRequestsWidget::class,
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                Authenticate::class,
                \Illuminate\Auth\Middleware\Authorize::class . ':accessRestaurantFilament', // ✅ الربط مع Gate
            ]);
    }
}
