<?php

namespace App\Providers\Filament;

use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Pages;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\Widgets;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;
use Modules\Admin\Filament\Widgets\AdminOverviewChartWidget;
use Modules\Admin\Filament\Widgets\AdminStats;
use Modules\Admin\Filament\Widgets\WelcomeWidget;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->id('admin')
            ->path('admin')
            ->brandName('Tawfir Admin Portal')
            ->favicon('logo.png')
            ->login()
            ->authGuard('admin')            // ← use authGuard(), not guard()
            ->authPasswordBroker('admins')  // ← if you have password resets
            //->colors([
            //    'primary' => Color::Amber,
            //])
            ->discoverResources(
                in: base_path('Modules/Admin/Filament/Resources'),
                for: 'Modules\\Admin\\Filament\\Resources',
            )
            ->discoverPages(
                in: app_path('Modules/Admin/Filament/Pages'),
                for: 'Modules\\Admin\\Filament\\Pages')
            ->pages([
                Pages\Dashboard::class,
            ])
            ->discoverWidgets(
                in: app_path('Modules/Admin/Filament/Widgets'),
                for: 'Modules\\Admin\\Filament\\Widgets')
            ->widgets([
                WelcomeWidget::class,
                AdminStats::class,
                AdminOverviewChartWidget::class
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                \Filament\Http\Middleware\Authenticate::class,
                \Illuminate\Auth\Middleware\Authorize::class . ':accessAdminFilament', // ✅ Gate check
            ]);
    }
}
