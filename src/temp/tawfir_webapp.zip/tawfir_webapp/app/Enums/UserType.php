<?php

namespace App\Enums;

enum UserType: string
{
    case USER = 'user';
    case RESTAURANT = 'restaurant';
    case ADMIN = 'admin';
}