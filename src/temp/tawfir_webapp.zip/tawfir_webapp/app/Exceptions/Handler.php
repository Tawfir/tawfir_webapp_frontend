<?php

namespace App\Exceptions;

use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Throwable;

class Handler extends ExceptionHandler
{
    /** @var array<int,string> */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    public function register(): void
    {
        // reportable callbacks here if you need them
    }

    /* ----------  HELPER  ---------- */
    private function apiResponse(string $message, mixed $data, int $status)
    {
        return response()->json([
            'status'  => false,
            'data'    => $data,
            'message' => $message,
        ], $status);
    }

    /* ----------  VALIDATION  ---------- */
    protected function invalidJson($request, ValidationException $e)
    {
        return $this->apiResponse(
            'Validation failed',
            $e->errors(),
            $e->status          // 422 by default
        );
    }

    /* ----------  UNAUTHENTICATED  ---------- */
    protected function unauthenticated($request, AuthenticationException $e)
    {
        // API clients or API routes
        if ($request->expectsJson() || $request->is('api/*')) {
            return $this->apiResponse('Unauthenticated', null, 401);
        }

        // Which Filament panel?
        $firstSegment = $request->segment(1);   // 'restaurant', 'admin', …

        return match ($firstSegment) {
            'restaurant' => redirect()->guest(route('filament.restaurant.auth.login')),
            'admin'      => redirect()->guest(route('filament.admin.auth.login')),
            default      => redirect()->guest(route('filament.admin.auth.login')),
        };
    }

    /* ----------  EVERYTHING ELSE  ---------- */
    public function render($request, Throwable $e)
    {
        if ($request->expectsJson()) {
            // Validation is already handled above; handle all other exceptions here
            $status = $e instanceof HttpExceptionInterface
                ? $e->getStatusCode()
                : 500;

            // Hide internal details in production
            $message = app()->isLocal()
                ? $e->getMessage() ?: 'Server Error'
                : __('errors.' . $status)   // fallback: “Server Error”, “Not Found”, etc.
                ?? 'Server Error';

            return $this->apiResponse($message, null, $status);
        }

        // Web / Filament requests
        return parent::render($request, $e);
    }
}
