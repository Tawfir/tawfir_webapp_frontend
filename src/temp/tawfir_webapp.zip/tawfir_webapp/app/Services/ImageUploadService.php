<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ImageUploadService
{
    public function upload(UploadedFile $file, string $type = 'general'): array
    {
        $folder = match ($type) {
            'profile' => 'restaurants/profile',
            'cover'   => 'restaurants/cover',
            'dish'    => 'dishes',
            'place'   => 'restaurants/places',
            // add these two:
            'food-category-cover' => 'food-categories/covers',
            'food-category-image' => 'food-categories/images',
            default   => 'uploads'
        };

        // ✅ Use store() instead, let Laravel generate a name
        $path = $file->store($folder, 'public');

        return [
            'url'  => asset("storage/$path"),
            'path' => $path,
        ];
    }

}
